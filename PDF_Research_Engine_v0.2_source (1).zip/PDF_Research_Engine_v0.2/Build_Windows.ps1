# Run on a Windows x64 build machine with Python 3.12 x64 installed.
# The end user receives only PDFResearchEngine.exe, not these build prerequisites.
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$ClamAVZip,
    [Parameter(Mandatory=$true)][ValidatePattern('^[a-fA-F0-9]{64}$')][string]$ClamAVSHA256,
    [Parameter(Mandatory=$true)][string]$EnglishTessdata,
    [Parameter(Mandatory=$true)][ValidatePattern('^[a-fA-F0-9]{64}$')][string]$TessdataSHA256,
    [switch]$LiveTest
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
function Assert-Native { param([string]$Step) if ($LASTEXITCODE -ne 0) { throw "$Step failed with exit code $LASTEXITCODE" } }
function Assert-Hash { param([string]$Path,[string]$Expected)
    if ((Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash -ne $Expected) { throw "SHA-256 mismatch: $Path" }
}
if ($env:OS -ne 'Windows_NT') { throw 'A native Windows build host is required.' }
$zip = (Resolve-Path -LiteralPath $ClamAVZip).Path
$tess = (Resolve-Path -LiteralPath $EnglishTessdata).Path
Assert-Hash $zip $ClamAVSHA256
Assert-Hash $tess $TessdataSHA256
$root = $PSScriptRoot
$work = Join-Path $root ('.build-win-' + [Guid]::NewGuid().ToString('N'))
$stage = Join-Path $work 'source'
$venv = Join-Path $work 'venv'
$dist = Join-Path $root 'dist'
New-Item -ItemType Directory -Path $stage,$dist | Out-Null
$exe = Join-Path $dist 'PDFResearchEngine.exe'
if (Test-Path $exe) { throw 'Move the previous dist/PDFResearchEngine.exe before building a new one.' }
& py -3.12 -c "import sys,struct; assert sys.platform=='win32' and struct.calcsize('P')==8 and sys.version_info[:2]==(3,12)"
Assert-Native 'Python architecture check'
& py -3.12 -m venv $venv
Assert-Native 'Virtual environment'
$python = Join-Path $venv 'Scripts\python.exe'
& $python -m pip install --only-binary=:all: -r (Join-Path $root 'build-requirements.txt')
Assert-Native 'Free Python dependency installation'
foreach ($name in @('app.py','engine.py','security.py','diagnostics.py','test_engine.py','test_security.py','pdf_rules.yar')) {
    Copy-Item -LiteralPath (Join-Path $root $name) -Destination $stage
}
$vendor = Join-Path $stage 'vendor'
$clamDir = Join-Path $vendor 'clamav'
$tessDir = Join-Path $vendor 'tessdata'
New-Item -ItemType Directory -Path $clamDir,$tessDir | Out-Null
$unpacked = Join-Path $work 'clamav-unpacked'
Expand-Archive -LiteralPath $zip -DestinationPath $unpacked
$candidates = @(Get-ChildItem -LiteralPath $unpacked -Filter 'clamscan.exe' -Recurse -File | Where-Object { Test-Path (Join-Path $_.Directory.FullName 'freshclam.exe') })
if ($candidates.Count -ne 1) { throw 'Expected one official x64 ClamAV portable package with both clamscan.exe and freshclam.exe.' }
Get-ChildItem -LiteralPath $candidates[0].Directory.FullName -Force | Copy-Item -Destination $clamDir -Recurse -Force
Copy-Item -LiteralPath $tess -Destination (Join-Path $tessDir 'eng.traineddata')
Push-Location $stage
try {
    & $python -m unittest -v test_engine.py test_security.py
    Assert-Native 'Regression and OCR tests'
    $report = Join-Path $work 'source-diagnostics.json'
    & $python app.py --diagnostics $report
    Assert-Native 'Source dependency diagnostics'
    & $python -m PyInstaller --noconfirm --clean --onefile --windowed --noupx --name PDFResearchEngine `
        --distpath (Join-Path $work 'dist') --workpath (Join-Path $work 'pyinstaller') --specpath $work `
        --add-data 'pdf_rules.yar;.' --add-data 'vendor/clamav;vendor/clamav' --add-data 'vendor/tessdata;vendor/tessdata' `
        --collect-all pymupdf --hidden-import yara --exclude-module nltk app.py
    Assert-Native 'Windows one-file packaging'
    $candidate = Join-Path $work 'dist\PDFResearchEngine.exe'
    if (-not (Test-Path $candidate)) { throw 'Executable was not produced.' }
    $packagedReport = Join-Path $work 'packaged-diagnostics.json'
    $mode = '--diagnostics'; if ($LiveTest) { $mode = '--live-self-test' }
    $proc = Start-Process -FilePath $candidate -ArgumentList @($mode, ('"' + $packagedReport + '"')) -PassThru -Wait
    if ($proc.ExitCode -ne 0 -or -not (Test-Path $packagedReport)) { throw 'Packaged diagnostic failed. Inspect the temporary build folder.' }
    $parsed = Get-Content -Raw -LiteralPath $packagedReport | ConvertFrom-Json
    if ($parsed.status -ne 'passed') { throw 'Packaged diagnostic did not pass.' }
    Copy-Item -LiteralPath $candidate -Destination $exe
    Copy-Item -LiteralPath $packagedReport -Destination (Join-Path $dist 'BUILD_DIAGNOSTICS.json')
    (Get-FileHash -Algorithm SHA256 -LiteralPath $exe).Hash + '  PDFResearchEngine.exe' | Set-Content -Encoding ASCII (Join-Path $dist 'SHA256.txt')
    & $python -m pip freeze | Set-Content -Encoding ASCII (Join-Path $dist 'BUILD_DEPENDENCIES.txt')
    Assert-Native 'Dependency inventory'
    Write-Host "Built: $exe"
    Write-Host 'Test the unsigned executable on a clean Windows x64 VM before distributing. See README and THIRD_PARTY_NOTICES.'
} finally { Pop-Location }
