"""Fail-closed document pipeline. Native worker is NOT an OS security sandbox."""
from __future__ import annotations
from contextlib import contextmanager
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import time
import uuid
from engine import HEADER, MAX_PDF

MAX_PAGES = 100
MAX_AGE = 7 * 86400
MAX_PIXELS = 12_000_000
MAX_TEXT = 400_000
WORKER_TIMEOUT = 600
BASE = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent))
RULES = BASE / 'pdf_rules.yar'

class Blocked(Exception):
    def __init__(self, reason, verdict='blocked'):
        super().__init__(reason)
        self.verdict = verdict

def sha256(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(1024*1024), b''):
            h.update(b)
    return h.hexdigest()

def file_check(path):
    path = Path(path)
    if path.is_symlink() or not path.is_file() or not 16 <= path.stat().st_size <= MAX_PDF:
        raise Blocked('Invalid file or file size')
    with path.open('rb') as f:
        if not HEADER.match(f.read(1024)):
            raise Blocked('Not a genuine PDF header')
        f.seek(max(0, path.stat().st_size-4096))
        if not re.search(rb'%%EOF\s*$', f.read()):
            raise Blocked('Missing PDF end marker')

def component(name):
    exe = name + ('.exe' if os.name == 'nt' else '')
    bundled = BASE / 'vendor' / 'clamav' / exe
    if bundled.is_file():
        return str(bundled.resolve())
    if getattr(sys, 'frozen', False):
        raise Blocked(f'Bundled {exe} missing', 'unavailable')
    p = shutil.which(exe)
    if p:
        return str(Path(p).resolve())
    raise Blocked(f'{exe} is not installed', 'unavailable')

def tessdata():
    paths = [BASE/'vendor'/'tessdata']
    if not getattr(sys, 'frozen', False):
        if os.environ.get('TESSDATA_PREFIX'):
            paths.append(Path(os.environ['TESSDATA_PREFIX']))
        paths += [Path('/usr/share/tesseract-ocr/5/tessdata'),Path('/usr/share/tessdata')]
    for p in paths:
        if (p/'eng.traineddata').is_file():
            return str(p.resolve())
    raise Blocked('English OCR language data missing', 'unavailable')

def run(args, timeout, cwd=None):
    # No shell, no inherited stdin, limited elapsed time. Same-user process, not sandboxed.
    try:
        r = subprocess.run([str(a) for a in args], stdin=subprocess.DEVNULL,
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout,
                           cwd=cwd, creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        if len(r.stdout)+len(r.stderr)>2_000_000:
            raise Blocked('Security tool output exceeded limit', 'unavailable')
        return r.returncode, (r.stdout+b'\n'+r.stderr).decode('utf-8','replace')
    except (OSError, subprocess.TimeoutExpired) as e:
        raise Blocked(f'Security tool could not finish: {type(e).__name__}', 'unavailable') from e

def db_state(db):
    """CVD/CLD embedded header build time, not writable filesystem mtime."""
    db=Path(db)
    details={}
    for name in ('main','daily','bytecode'):
        matches=[db/(name+s) for s in ('.cvd','.cld') if (db/(name+s)).is_file()]
        if len(matches)!=1:
            raise Blocked(f'Expected exactly one {name} signature database', 'unavailable')
        with matches[0].open('rb') as f:
            fields=f.read(512).rstrip(b' \x00').decode('ascii','strict').split(':')
        # The build date field contains colons; the epoch is the final field.
        try:
            if fields[0]!='ClamAV-VDB' or len(fields)<9: raise ValueError()
            stamp=int(fields[-1]);
            if not 1_000_000_000 < stamp <= time.time()+86400: raise ValueError()
        except (ValueError, IndexError):
            raise Blocked(f'Invalid {name} signature header', 'unavailable')
        st=matches[0].stat();details[name]={'file':matches[0].name,'build_epoch':stamp,'bytes':st.st_size,'mtime_ns':st.st_mtime_ns}
    if time.time()-details['daily']['build_epoch']>MAX_AGE:
        raise Blocked('Daily malware definitions older than seven days', 'unavailable')
    return details

def dependencies():
    component('clamscan'); component('freshclam'); tessdata()
    try:
        import yara
        import pymupdf
        rules=yara.compile(filepath=str(RULES))
    except Exception as e:
        raise Blocked(f'YARA or PDF/OCR engine unavailable: {type(e).__name__}', 'unavailable') from e
    return rules

def update_definitions(root):
    root=Path(root); db=root/'definitions'; db.mkdir(parents=True,exist_ok=True)
    # This is a distinct, fixed-vendor update channel, never a research URL.
    config=root/'freshclam.conf'
    # A newline/quote in path could change config directives; reject such paths.
    if any(x in str(db) for x in ('\n','\r','"')):
        raise Blocked('Invalid database directory', 'unavailable')
    config.write_text('DatabaseMirror database.clamav.net\nChecks 12\nConnectTimeout 15\nReceiveTimeout 120\n',encoding='utf-8')
    rc,out=run([component('freshclam'),'--config-file='+str(config.resolve()),'--datadir='+str(db.resolve()),'--stdout'],300,cwd=root)
    if rc!=0:
        raise Blocked('FreshClam update failed: '+out[-350:], 'unavailable')
    return db_state(db)

def clam_scan(path,db):
    state=db_state(db)
    rc,out=run([component('clamscan'),'--database='+str(Path(db).resolve()),'--stdout',
                '--alert-exceeds-max=yes','--alert-encrypted=yes','--max-filesize=60M',
                '--max-scansize=200M','--max-scantime=120000','--bytecode=yes',str(Path(path).resolve())],150,cwd=Path(path).parent)
    if rc==1:
        # Heuristics/limits can use return code 1 as well as signature detections.
        if re.search(r'(?i)Heuristics\.|Exceeded|Encrypted',out):
            raise Blocked('ClamAV flagged heuristic, encrypted or inspection-limit content: '+out[-500:], 'suspicious')
        raise Blocked('ClamAV detected a threat: '+out[-500:], 'malware')
    if rc!=0 or not re.search(r'(?m)^Scanned files:\s*1\s*$',out) or not re.search(r'(?m)^Infected files:\s*0\s*$',out) or re.search(r'(?im)^\s*(?:ERROR|WARNING):',out):
        raise Blocked('ClamAV did not establish a complete clean scan: '+out[-350:], 'unavailable')
    return state

def yara_scan(path,rules):
    try:
        matches=rules.match(filepath=str(path),timeout=20)
    except Exception as e:
        raise Blocked('YARA did not finish: '+type(e).__name__, 'unavailable') from e
    if matches:
        raise Blocked('YARA policy match: '+', '.join(str(m.rule) for m in matches)[:300], 'suspicious')

ACTIVE = re.compile(r'/(?:JavaScript|JS|Launch|EmbeddedFile|EmbeddedFiles|RichMedia|XFA|AA|OpenAction|SubmitForm|ImportData|GoToR|GoToE|Movie|Sound|Rendition|3D)(?=[\s/<>{}\[\]()%]|$)')

def normalize_names(s):
    return re.sub(r'#([0-9A-Fa-f]{2})',lambda m:chr(int(m.group(1),16)),s)

def inspect_document(doc):
    if not doc.is_pdf or doc.is_encrypted or doc.needs_pass or doc.is_repaired:
        raise Blocked('Encrypted, repaired or invalid PDF', 'suspicious')
    if not 1<=doc.page_count<=MAX_PAGES or doc.xref_length()>150_000:
        raise Blocked('PDF page/object limit exceeded', 'suspicious')
    if doc.embfile_count():
        raise Blocked('PDF includes attachments', 'suspicious')
    for x in range(1,doc.xref_length()):
        obj=doc.xref_object(x,compressed=False)
        if len(obj)>2_000_000 or ACTIVE.search(normalize_names(obj)):
            raise Blocked('PDF has active content or oversized objects', 'suspicious')

def reconstruct(src,dest):
    import pymupdf as f
    language_data=tessdata()
    with f.open(str(src),filetype='pdf') as doc, f.open() as rebuilt:
        inspect_document(doc)
        for page in doc:
            rect=page.rect
            if not (0<rect.width<=5000 and 0<rect.height<=5000):
                raise Blocked('Excessive PDF page dimensions','suspicious')
            dpi=150
            pixels=(rect.width*dpi/72+1)*(rect.height*dpi/72+1)
            if pixels>MAX_PIXELS:
                raise Blocked('Page raster size exceeds limit','suspicious')
            pix=page.get_pixmap(dpi=dpi,colorspace=f.csRGB,alpha=False,annots=False)
            # Recreate solely from rendered pixels and English OCR, not original PDF objects.
            blob=pix.pdfocr_tobytes(compress=True,language='eng',tessdata=language_data)
            with f.open('pdf',blob) as new_page:
                rebuilt.insert_pdf(new_page,links=False,annots=False,widgets=False)
            del pix,blob
        rebuilt.set_metadata({'producer':'PDF Research v0.2; rasterized OCR derivative'})
        rebuilt.save(str(dest),garbage=4,deflate=True)
    file_check(dest)
    with f.open(str(dest),filetype='pdf') as final:
        inspect_document(final)
        body=[];remaining=MAX_TEXT
        for n,p in enumerate(final,1):
            text=p.get_text('text')
            if remaining<=0:break
            block=f'\n[Page {n}]\n'+text[:remaining]
            body.append(block);remaining-=len(block)
        text=''.join(body)[:MAX_TEXT]
        searchable=any(p.get_text('text').strip() for p in final)
        return text if searchable else '',final.page_count,searchable

def require_standard_user():
    if os.name=='nt':
        import ctypes
        if ctypes.windll.shell32.IsUserAnAdmin():raise Blocked('Do not run the application as administrator','unavailable')

def native_worker(mode,root,folder):
    """Only worker entry; never takes a URL or opens a viewer."""
    root=Path(root); folder=Path(folder); db=root/'definitions'
    try:
        require_standard_user()
        rules=dependencies()
        if mode=='update':
            return {'verdict':'ready','definitions':update_definitions(root)}
        if mode=='status':
            return {'verdict':'ready','definitions':db_state(db)}
        if mode not in ('inspect','rescan'):
            raise Blocked('Unknown worker operation')
        src=folder/'input.quarantine'; dest=folder/'rebuilt.pending'
        file_check(src); digest=sha256(src)
        defs=clam_scan(src,db); yara_scan(src,rules)
        if mode=='inspect':
            text,pages,searchable=reconstruct(src,dest)
            if not searchable:
                raise Blocked('OCR found no searchable text; document not released','suspicious')
            second=clam_scan(dest,db); yara_scan(dest,rules)
            if defs!=second:
                raise Blocked('Definitions changed during inspection','unavailable')
            output=sha256(dest)
        else:
            import pymupdf as f
            with f.open(str(src),filetype='pdf') as doc:
                inspect_document(doc)
            text='';pages=0;searchable=True;output=digest
        if sha256(src)!=digest:
            raise Blocked('Input changed during inspection','suspicious')
        return {'verdict':'passed','input_sha256':digest,'output_sha256':output,'definitions':defs,
                'rules_sha256':sha256(RULES),'text':text,'pages':pages,'searchable':searchable}
    except Blocked as e:
        return {'verdict':e.verdict,'reason':str(e)[:1000]}
    except Exception as e:
        return {'verdict':'unavailable','reason':f'Inspection failed: {type(e).__name__}: {str(e)[:300]}'}

def worker_entry(args):
    mode,root,folder=args
    folder=Path(folder)
    result=native_worker(mode,Path(root),folder)
    (folder/'result.json').write_text(json.dumps(result,ensure_ascii=True),encoding='utf-8')

def invoke(mode,root,folder):
    root=Path(root).resolve(); folder=Path(folder).resolve()
    result_file=folder/'result.json'; result_file.unlink(missing_ok=True)
    cmd=[sys.executable]
    if not getattr(sys,'frozen',False):cmd += [str(BASE/'app.py')]
    cmd += ['--security-worker',mode,str(root),str(folder)]
    rc,out=run(cmd,WORKER_TIMEOUT,cwd=folder)
    if rc!=0 or not result_file.is_file() or result_file.stat().st_size>2_000_000:
        raise Blocked('Security worker failed or provided no valid result', 'unavailable')
    try:result=json.loads(result_file.read_text(encoding='utf-8'))
    except Exception as e:raise Blocked('Security worker returned invalid output','unavailable') from e
    if not isinstance(result,dict) or result.get('verdict') not in ('ready','passed','malware','suspicious','blocked','unavailable'):
        raise Blocked('Unexpected security verdict','unavailable')
    return result

class Pipeline:
    """Gate between network retrieval and the searchable library. Originals never exported."""
    def __init__(self,root,threat_action='delete'):
        self.root=Path(root);self.root.mkdir(parents=True,exist_ok=True)
        if threat_action not in ('delete','quarantine'):raise ValueError('Invalid threat policy')
        self.threat_action=threat_action
        self.staging=self.root/'staging';self.staging.mkdir(exist_ok=True)
    def _call(self,mode):
        with tempfile.TemporaryDirectory(dir=self.staging) as td:
            return invoke(mode,self.root,Path(td))
    def status(self):return self._call('status')
    def update(self):return self._call('update')
    def ensure_ready(self):
        r=self.status()
        if r.get('verdict')!='ready':
            r=self.update()
        if r.get('verdict')!='ready':raise Blocked(r.get('reason','Security unavailable'),'unavailable')
        return r
    def audit(self,entry):
        entry={'utc':dt.datetime.now(dt.timezone.utc).isoformat(),**entry}
        with (self.root/'security.jsonl').open('a',encoding='utf-8') as f:
            f.write(json.dumps(entry,ensure_ascii=True)+'\n')
    def process(self,net,result):
        with tempfile.TemporaryDirectory(dir=self.staging) as td:
            folder=Path(td);digest='';final=result.url;size=0
            try:
                db_state(self.root/'definitions')
                src,digest,size,final=net.download(result.url,folder)
                src.rename(folder/'input.quarantine')
                if sha256(folder/'input.quarantine')!=digest:raise Blocked('Retrieved file hash mismatch','suspicious')
                r=invoke('inspect',self.root,folder)
                if r.get('verdict')!='passed':raise Blocked(r.get('reason','No inspection result'),r.get('verdict','unavailable'))
                dest=folder/'rebuilt.pending';file_check(dest)
                if (r.get('input_sha256')!=digest or sha256(folder/'input.quarantine')!=digest or
                    not re.fullmatch('[a-f0-9]{64}',str(r.get('output_sha256',''))) or sha256(dest)!=r['output_sha256'] or
                    r.get('searchable') is not True or type(r.get('pages')) is not int or not 1<=r['pages']<=MAX_PAGES or not isinstance(r.get('text'),str) or not r['text'].strip() or
                    not isinstance(r.get('definitions'),dict) or r['definitions']!=db_state(self.root/'definitions') or r.get('rules_sha256')!=sha256(RULES)):
                    raise Blocked('Inspection evidence did not match staged bytes or current policy','suspicious')
                # Cache derivative under a non-PDF extension; explicit export is separate.
                cache=self.root/'processed';cache.mkdir(exist_ok=True)
                target=cache/(r['output_sha256']+'.screened')
                if target.exists():
                    if sha256(target)!=r['output_sha256']:raise Blocked('Cached derivative hash mismatch','suspicious')
                else:os.replace(dest,target)
                self.audit({'url':final,'original_sha256':digest,'output_sha256':r['output_sha256'],'verdict':'passed','definitions':r['definitions'],'rules_sha256':r['rules_sha256'],'pages':r.get('pages')})
                return dict(r,digest=digest,size=size,url=final)
            except Exception as e:
                verdict=e.verdict if isinstance(e,Blocked) else 'unavailable'
                reason=str(e)[:1000]; src=folder/'input.quarantine'
                # Preserve only suspicious files or explicit malware quarantine, never unscanned errors.
                if src.is_file() and (verdict=='suspicious' or (verdict=='malware' and self.threat_action=='quarantine')):
                    q=self.root/'quarantine';q.mkdir(exist_ok=True)
                    os.replace(src,q/(uuid.uuid4().hex+'.quarantine'))
                    disposition='quarantined'
                else:disposition='removed from staging'
                self.audit({'url':final,'original_sha256':digest,'verdict':verdict,'reason':reason,'disposition':disposition})
                return {'verdict':verdict,'reason':reason,'digest':digest,'size':size,'url':final,'disposition':disposition}
    @contextmanager
    def checked_derivative(self,digest):
        """Fresh dual scan of the exact bytes held for recheck or release."""
        if not re.fullmatch('[a-f0-9]{64}',digest):raise Blocked('Invalid derivative identifier')
        db_state(self.root/'definitions')
        src=self.root/'processed'/(digest+'.screened')
        if not src.is_file() or sha256(src)!=digest:raise Blocked('Derivative absent or changed','suspicious')
        with tempfile.TemporaryDirectory(dir=self.staging) as td:
            folder=Path(td);staged=folder/'input.quarantine';shutil.copyfile(src,staged)
            if sha256(staged)!=digest:raise Blocked('Copy hash mismatch','suspicious')
            r=invoke('rescan',self.root,folder)
            if r.get('verdict')!='passed':
                if r.get('verdict') in ('malware','suspicious'):
                    if r['verdict']=='malware' and self.threat_action=='delete':src.unlink(missing_ok=True)
                    else:
                        q=self.root/'quarantine';q.mkdir(exist_ok=True);os.replace(src,q/(uuid.uuid4().hex+'.quarantine'))
                self.audit({'output_sha256':digest,'verdict':r.get('verdict'),'reason':r.get('reason'),'operation':'rescan denied'})
                raise Blocked(r.get('reason','Rescan failed'),r.get('verdict','unavailable'))
            if (r.get('input_sha256')!=digest or r.get('output_sha256')!=digest or sha256(staged)!=digest or
                r.get('definitions')!=db_state(self.root/'definitions') or r.get('rules_sha256')!=sha256(RULES)):
                raise Blocked('Rescan evidence mismatch','suspicious')
            yield staged,r
    def recheck(self,digest):
        with self.checked_derivative(digest) as (_,r):
            self.audit({'output_sha256':digest,'verdict':'passed','operation':'library rescan','definitions':r['definitions'],'rules_sha256':r['rules_sha256']})
    def export(self,digest,directory):
        self.ensure_ready()
        with self.checked_derivative(digest) as (staged,r):
            # Do not overwrite an existing user file. Export exact staged bytes, not re-fetch URL.
            target=Path(directory)/('PDFResearch_'+digest[:20]+'.pdf')
            pending=Path(directory)/('.PDFResearch_'+uuid.uuid4().hex+'.pending')
            try:
                with pending.open('xb') as f,staged.open('rb') as inp:shutil.copyfileobj(inp,f)
                if sha256(pending)!=digest:raise Blocked('Exported copy hash mismatch','suspicious')
                # hard-link creation is atomic and fails if target exists; no unsafe overwrite fallback.
                os.link(pending,target)
            finally:pending.unlink(missing_ok=True)
            self.audit({'output_sha256':digest,'verdict':'passed','operation':'export','definitions':r['definitions'],'rules_sha256':r['rules_sha256']})
            return target

class ScreenedLibrary:
    """Separate v0.2 index; never imports v0.1 unscanned documents."""
    def __init__(self,root):
        import sqlite3
        self.root=Path(root); self.root.mkdir(parents=True,exist_ok=True)
        self.db=self.root/'screened.sqlite3'
        with self.connect() as c:
            c.execute('CREATE TABLE IF NOT EXISTS documents (original TEXT PRIMARY KEY, derivative TEXT NOT NULL, title TEXT, source TEXT, year TEXT, url TEXT, pages INTEGER, body TEXT, status TEXT, scanned TEXT)')
    @contextmanager
    def connect(self):
        import sqlite3
        c=sqlite3.connect(self.db,timeout=10)
        try:
            with c:yield c
        finally:c.close()
    def save(self,result,r):
        if r.get('verdict')!='passed' or not re.fullmatch('[a-f0-9]{64}',r.get('digest','')) or not re.fullmatch('[a-f0-9]{64}',r.get('output_sha256','')):
            raise Blocked('Cannot index unverified data')
        target=self.root/'processed'/(r['output_sha256']+'.screened')
        if not target.is_file() or sha256(target)!=r['output_sha256']:raise Blocked('Cannot index missing or changed derivative')
        with self.connect() as c:
            c.execute('INSERT OR REPLACE INTO documents VALUES (?,?,?,?,?,?,?,?,?,?)',(r['digest'],r['output_sha256'],result.title,result.source,result.year,r['url'],r['pages'],r['text'][:MAX_TEXT],'Screened / OCR indexed',dt.datetime.now(dt.timezone.utc).isoformat()))
    def search(self,query=''):
        with self.connect() as c:
            return c.execute('SELECT derivative,title,source,year,status,url,pages FROM documents WHERE instr(lower(title||" "||body),lower(?))>0 OR ?="" ORDER BY rowid DESC LIMIT 1000',(query,query)).fetchall()
    def text(self,digest):
        with self.connect() as c:
            r=c.execute('SELECT body FROM documents WHERE derivative=? AND status=?',(digest,'Screened / OCR indexed')).fetchone()
            return r[0] if r else ''
    def blocked(self,digest,reason):
        with self.connect() as c:c.execute('UPDATE documents SET status=?,body="" WHERE derivative=?',('Blocked / '+str(reason)[:90],digest))

    def active_digests(self):
        with self.connect() as c:return [r[0] for r in c.execute('SELECT DISTINCT derivative FROM documents WHERE status=?',('Screened / OCR indexed',))]

@contextmanager
def single_instance(root):
    """Prevent normal concurrent GUI instances from racing definition updates and processing."""
    root=Path(root);root.mkdir(parents=True,exist_ok=True)
    with (root/'app.lock').open('a+b') as f:
        f.seek(0,os.SEEK_END)
        if f.tell()==0:f.write(b'0');f.flush()
        f.seek(0)
        if os.name=='nt':
            import msvcrt
            try:msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1)
            except OSError as e:raise Blocked('Another PDF Research instance is running','unavailable') from e
            try:yield
            finally:f.seek(0);msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1)
        else:
            import fcntl
            try:fcntl.flock(f.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
            except OSError as e:raise Blocked('Another PDF Research instance is running','unavailable') from e
            try:yield
            finally:fcntl.flock(f.fileno(),fcntl.LOCK_UN)
