# Component and redistribution notes

This source package contains the application code, a small locally authored YARA policy, tests, build configuration, and documentation. It does **not** contain downloaded third-party binaries or malware-definition databases.

The Windows build uses CPython/Tk (PSF and Tcl/Tk licenses), PyInstaller (GPL with its bootloader exception), YARA and yara-python (BSD-style licenses), ClamAV/FreshClam (GPLv2), PyMuPDF/MuPDF (AGPLv3 or commercial licensing), and Tesseract/English traineddata (Apache 2.0 for upstream Tesseract and tessdata_fast). SQLite is public domain. Consult the actual versions' accompanying licenses and notices, including transitive native libraries. These summaries are not a substitute for the upstream license terms.

The supplied prototype application source may be used, studied, modified and shared under the GNU Affero General Public License, version 3 or later, to align with the open-source PyMuPDF dependency. License text: https://www.gnu.org/licenses/agpl-3.0.txt . Source and build scripts are included. Before public distribution of a compiled executable, review the exact dependencies' redistribution obligations; include required copyright/license notices and make the corresponding source for copyleft components available as required. The Windows builder is for development, not a completed licensing audit. Keep the source archive and verified build input inventory with any build you share. ClamAV is invoked as a separate executable. Do not assume the presence of a single-file package removes these obligations.

Upstream project locations (not fetched or independently verified in this environment):
- https://www.clamav.net/downloads and https://github.com/Cisco-Talos/clamav
- https://github.com/VirusTotal/yara and https://github.com/VirusTotal/yara-python
- https://github.com/pymupdf/PyMuPDF
- https://github.com/tesseract-ocr/tessdata_fast
- https://pyinstaller.org/
- https://www.python.org/

No commercial malware API or AI service is used. FreshClam retrieves its vendor-provided signature databases; the document bytes are scanned locally and are never submitted to a cloud scanning service. The included YARA rules are conservative feature flags, not an external threat-intelligence feed.
