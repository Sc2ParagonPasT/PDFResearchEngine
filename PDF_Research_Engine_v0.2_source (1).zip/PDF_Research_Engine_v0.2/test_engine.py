import unittest, tempfile, io, threading
from pathlib import Path
from unittest.mock import patch
from engine import *

class Response(io.BytesIO):
    status=200
    def getheader(self,key,default=None):return {'Content-Type':'application/pdf'}.get(key,default)
class Connection:
    def close(self):pass
class Tests(unittest.TestCase):
    def test_allowlist(self):
        hosts={'www.cia.gov'}
        self.assertEqual(checked_url('https://www.cia.gov/a.pdf#x',hosts),'https://www.cia.gov/a.pdf')
        for x in ['http://www.cia.gov/a.pdf','https://www.cia.gov.evil.com/a.pdf','https://www.cia.gov@evil.com/a.pdf','https://evil.com@www.cia.gov/a.pdf','https://www.cia.gov:8080/a.pdf','https://127.0.0.1/a.pdf','https://www.cia.gov\\@evil.com/a.pdf','https://cia.gov/a.pdf']:
            with self.subTest(x=x),self.assertRaises(ValueError):checked_url(x,hosts)
    def test_private_dns(self):
        with patch('engine.socket.getaddrinfo',return_value=[(None,None,None,None,('127.0.0.1',443))]):
            with self.assertRaises(ValueError):public_ips('www.cia.gov')
    def test_expansion(self):
        terms=expand('Hatred in society, sociology papers','Comprehensive')
        self.assertEqual(terms[0],'Hatred in society, sociology papers');self.assertEqual(len(terms),12);self.assertTrue(any('dehumanization' in t for t in terms));self.assertEqual(len(expand('Hatred in society','Focused')),5)
    def test_probe(self):
        n=Network(['www.cia.gov']);u='https://www.cia.gov/test'
        for content,ok in [(b'%PDF-1.7\nabc',True),(b'<html>download PDF</html>',False),(b'MZ%PDF-1.7\n',False)]:
            with patch.object(n,'open',return_value=(Connection(),Response(content),u)):
                if ok:self.assertEqual(n.probe(u)[0],u)
                else:
                    with self.assertRaises(ValueError):n.probe(u)
    def test_quarantine_dedupe(self):
        n=Network(['www.cia.gov']);u='https://www.cia.gov/test';payload=b'%PDF-1.7\nnot a real document\n%%EOF\n'
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(tmp)
            for _ in range(2):
                with patch.object(n,'open',return_value=(Connection(),Response(payload),u)):
                    file,digest,size,final=n.download(u,folder)
                    self.assertEqual(file.suffix,'.quarantine');self.assertEqual(size,len(payload));self.assertEqual(digest,hashlib.sha256(payload).hexdigest())
            self.assertEqual(len(list(folder.iterdir())),1)
            # A header/end marker is not structural validation; file remains quarantined.
            with patch.object(n,'open',return_value=(Connection(),Response(b'%PDF-1.7\ntruncated'),u)):
                with self.assertRaises(ValueError):n.download(u,folder)
            self.assertEqual(len(list(folder.iterdir())),1)
    def test_crossref_filters_links(self):
        n=Network(['api.crossref.org','www.cia.gov'])
        with patch.object(n,'json',return_value={'message':{'items':[{'title':['Example'],'link':[{'URL':'https://evil.example/x.pdf','content-type':'application/pdf'},{'URL':'https://www.cia.gov/x.pdf','content-type':'application/pdf'}]}]}}):
            items=discover(n,'Crossref','example');self.assertEqual(len(items),1);self.assertEqual(items[0].status,'Candidate (unverified)')
    def test_redirect_rechecked(self):
        class Redirect(Response):
            status=302
            def getheader(self,k,default=None):return 'https://evil.example/payload' if k=='Location' else default
        class FakeConn(Connection):
            def request(self,*a,**k):pass
            def getresponse(self):return Redirect(b'')
        n=Network(['www.cia.gov'])
        with patch('engine.PinnedHTTPS',return_value=FakeConn()) as conn:
            with self.assertRaises(ValueError):n.open('https://www.cia.gov/test')
            self.assertEqual(conn.call_count,1)
    def test_library(self):
        with tempfile.TemporaryDirectory() as tmp:
            lib=Library(tmp);r=Result('Test document','https://www.cia.gov/test','test');digest='a'*64
            lib.save(r,digest,100,r.url);self.assertEqual(lib.search()[0][4],'Quarantined / unscanned');lib.update(digest,'Text available / scanned','social hostility');self.assertEqual(len(lib.search('social hostility')),1);self.assertEqual(len(lib.search("' OR 1=1 --")),0)
    def test_unsafe_host_config(self):
        for s in ['*.gov','https://www.cia.gov','127.0.0.1','www.cia.gov/path']:
            with self.assertRaises(ValueError):exact_hosts([s])
    def test_parallel_dedupe(self):
        n=Network(['www.cia.gov']);events=[]
        with patch('engine.discover',return_value=[Result('Example','https://www.cia.gov/test','test')]):
            run_search(n,['ERIC','Crossref'],['foo','bar'],[],threading.Event(),lambda k,v:events.append((k,v)))
        self.assertEqual(sum(k=='result' for k,v in events),1)
if __name__=='__main__':unittest.main()
