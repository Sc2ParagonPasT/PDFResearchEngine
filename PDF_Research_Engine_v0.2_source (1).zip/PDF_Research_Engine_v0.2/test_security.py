"""Tests use mocked malware engines; actual PDF rendering/OCR uses local PyMuPDF when available."""
import hashlib, tempfile, time, unittest
from pathlib import Path
from unittest.mock import patch, Mock
from engine import Result
import security as s

# Deliberately not a real structured PDF; useful only as mock scanner data.
SAMPLE=b'%PDF-1.7\nmock payload\n%%EOF\n'
DERIVATIVE=b'%PDF-1.7\nmock screened derivative\n%%EOF\n'

def dbs(root,age=0):
    db=Path(root)/'definitions';db.mkdir(exist_ok=True)
    stamp=int(time.time()-age)
    for name in ('main','daily','bytecode'):
        # Fixture for the CVD/CLD header format, not actual signed databases.
        data=f'ClamAV-VDB:26 Nov 2026 10:12:00 +0000:1:2:3:hash:signature:builder:{stamp}'.encode()
        (db/(name+'.cvd')).write_bytes(data.ljust(512,b' '))
    return s.db_state(db) if age<=s.MAX_AGE else None

class Net:
    def __init__(self):self.calls=0
    def download(self,url,folder):
        self.calls+=1;h=hashlib.sha256(SAMPLE).hexdigest();p=Path(folder)/(h+'.quarantine');p.write_bytes(SAMPLE);return p,h,len(SAMPLE),url

class PipelineTests(unittest.TestCase):
    def setUp(self):
        self.td=tempfile.TemporaryDirectory();self.addCleanup(self.td.cleanup);self.root=Path(self.td.name)
        self.defs=dbs(self.root);self.pipe=s.Pipeline(self.root);self.net=Net();self.r=Result('Sample','https://www.cia.gov/p.pdf','test','2026','topic')
    def mock_pass(self,mode,root,folder):
        if mode in ('status','update'):return {'verdict':'ready','definitions':self.defs}
        original=s.sha256(folder/'input.quarantine')
        out=original
        if mode=='inspect':
            (folder/'rebuilt.pending').write_bytes(DERIVATIVE);out=s.sha256(folder/'rebuilt.pending')
        return {'verdict':'passed','input_sha256':original,'output_sha256':out,'definitions':self.defs,'rules_sha256':s.sha256(s.RULES),'searchable':True,'pages':1,'text':'Social hostility'}
    def accept(self):
        with patch('security.invoke',side_effect=self.mock_pass):
            return self.pipe.process(self.net,self.r)
    def test_clean_pipeline_and_export(self):
        with patch('security.invoke',side_effect=self.mock_pass) as w:
            evidence=self.pipe.process(self.net,self.r);self.assertEqual(evidence['verdict'],'passed');self.assertEqual(self.net.calls,1)
            self.assertEqual(list((self.root/'staging').iterdir()),[])
            self.assertFalse((self.root/'quarantine').exists())
            lib=s.ScreenedLibrary(self.root);lib.save(self.r,evidence)
            self.assertEqual(len(lib.search('social hostility')),1)
            self.assertEqual(lib.text(evidence['output_sha256']),'Social hostility')
            dest=self.root/'export';dest.mkdir();path=self.pipe.export(evidence['output_sha256'],dest)
            self.assertEqual(path.read_bytes(),DERIVATIVE);self.assertEqual(self.net.calls,1)
            self.assertIn('rescan',[c.args[0] for c in w.call_args_list])
            with self.assertRaises(FileExistsError):self.pipe.export(evidence['output_sha256'],dest)
            self.assertEqual(list(dest.iterdir()),[path])
    def test_malware_deleted(self):
        with patch('security.invoke',return_value={'verdict':'malware','reason':'mock detection'}):
            e=self.pipe.process(self.net,self.r)
        self.assertEqual(e['verdict'],'malware');self.assertFalse((self.root/'quarantine').exists());self.assertFalse((self.root/'processed').exists());self.assertEqual(list((self.root/'staging').iterdir()),[])
        self.assertIn('mock detection',(self.root/'security.jsonl').read_text())
    def test_malware_quarantined_by_setting(self):
        with patch('security.invoke',return_value={'verdict':'malware','reason':'mock detection'}):
            e=s.Pipeline(self.root,'quarantine').process(self.net,self.r)
        self.assertEqual(e['disposition'],'quarantined');self.assertEqual(len(list((self.root/'quarantine').glob('*.quarantine'))),1)
    def test_suspicious_quarantined(self):
        with patch('security.invoke',return_value={'verdict':'suspicious','reason':'active content'}):
            e=self.pipe.process(self.net,self.r)
        self.assertEqual(e['verdict'],'suspicious');self.assertFalse((self.root/'processed').exists());self.assertEqual(len(list((self.root/'quarantine').iterdir())),1)
    def test_scanner_failure_not_indexed(self):
        with patch('security.invoke',return_value={'verdict':'unavailable','reason':'timeout'}):
            e=self.pipe.process(self.net,self.r)
        self.assertEqual(e['verdict'],'unavailable');self.assertFalse((self.root/'processed').exists());self.assertEqual(list((self.root/'staging').iterdir()),[])
        with self.assertRaises(s.Blocked):s.ScreenedLibrary(self.root).save(self.r,e)
    def test_stale_db_blocks_before_fetch(self):
        dbs(self.root,age=s.MAX_AGE+10);e=self.pipe.process(self.net,self.r)
        self.assertEqual(e['verdict'],'unavailable');self.assertEqual(self.net.calls,0)
    def test_changed_derivative_rejected(self):
        def changed(mode,root,folder):
            r=self.mock_pass(mode,root,folder);(folder/'rebuilt.pending').write_bytes(SAMPLE);return r
        with patch('security.invoke',side_effect=changed):e=self.pipe.process(self.net,self.r)
        self.assertEqual(e['verdict'],'suspicious');self.assertFalse((self.root/'processed').exists())
    def test_changed_definitions_rejected(self):
        def changed(mode,root,folder):
            r=self.mock_pass(mode,root,folder);r['definitions']={};return r
        with patch('security.invoke',side_effect=changed):e=self.pipe.process(self.net,self.r)
        self.assertEqual(e['verdict'],'suspicious')
    def test_missing_searchable_text_rejected(self):
        def no_text(mode,root,folder):
            r=self.mock_pass(mode,root,folder);r['text']='';r['searchable']=False;return r
        with patch('security.invoke',side_effect=no_text):e=self.pipe.process(self.net,self.r)
        self.assertEqual(e['verdict'],'suspicious')
    def test_export_rescan_detects_new_threat(self):
        e=self.accept();digest=e['output_sha256'];dest=self.root/'export';dest.mkdir()
        def detected(mode,root,folder):
            if mode=='rescan':return {'verdict':'malware','reason':'new mock signature'}
            return self.mock_pass(mode,root,folder)
        with patch('security.invoke',side_effect=detected):
            with self.assertRaises(s.Blocked):self.pipe.export(digest,dest)
        self.assertFalse((self.root/'processed'/(digest+'.screened')).exists());self.assertEqual(list(dest.iterdir()),[])
    def test_library_recheck_detects_new_threat(self):
        e=self.accept();digest=e['output_sha256'];lib=s.ScreenedLibrary(self.root);lib.save(self.r,e)
        with patch('security.invoke',return_value={'verdict':'malware','reason':'new signature'}):
            with self.assertRaises(s.Blocked) as ex:self.pipe.recheck(digest)
        lib.blocked(digest,str(ex.exception))
        self.assertEqual(lib.active_digests(),[]);self.assertEqual(lib.text(digest),'');self.assertFalse((self.root/'processed'/(digest+'.screened')).exists())
    def test_single_instance_lock(self):
        with s.single_instance(self.root):
            with self.assertRaises(s.Blocked):
                with s.single_instance(self.root):pass
        with s.single_instance(self.root):pass
    def test_export_tampered_cache(self):
        e=self.accept();digest=e['output_sha256'];(self.root/'processed'/(digest+'.screened')).write_bytes(SAMPLE)
        with patch('security.invoke',side_effect=self.mock_pass):
            with self.assertRaises(s.Blocked):self.pipe.export(digest,self.root)
        self.assertEqual(list(self.root.glob('*.pdf')),[])
    def test_scan_summary_must_confirm_one_file(self):
        p=self.root/'fixture';p.write_bytes(SAMPLE)
        with patch('security.component',return_value='fake-clamscan'):
            for code,summary in [(0,'Scanned files: 0\nInfected files: 0'),(2,'ERROR'),(0,'Scanned files: 1\nInfected files: 0\nWARNING: skipped')]:
                with patch('security.run',return_value=(code,summary)):
                    with self.assertRaises(s.Blocked):s.clam_scan(p,self.root/'definitions')
            with patch('security.run',return_value=(0,'Scanned files: 1\nInfected files: 0')):self.assertEqual(s.clam_scan(p,self.root/'definitions'),self.defs)
    def test_clam_heuristic_not_definitive_malware(self):
        p=self.root/'fixture';p.write_bytes(SAMPLE)
        with patch('security.component',return_value='fake-clamscan'),patch('security.run',return_value=(1,'Heuristics.Limits.Exceeded FOUND')):
            with self.assertRaises(s.Blocked) as ex:s.clam_scan(p,self.root/'definitions')
        self.assertEqual(ex.exception.verdict,'suspicious')
    def test_yara_match_and_error_block(self):
        p=self.root/'fixture';p.write_bytes(SAMPLE);rules=Mock()
        rules.match.return_value=[Mock(rule='TestRule')]
        with self.assertRaises(s.Blocked) as ex:s.yara_scan(p,rules)
        self.assertEqual(ex.exception.verdict,'suspicious')
        rules.match.side_effect=RuntimeError('error')
        with self.assertRaises(s.Blocked) as ex:s.yara_scan(p,rules)
        self.assertEqual(ex.exception.verdict,'unavailable')
    def test_worker_two_scans_each_engine(self):
        folder=self.root/'job';folder.mkdir();(folder/'input.quarantine').write_bytes(SAMPLE)
        def rebuild(src,dest):dest.write_bytes(DERIVATIVE);return 'text',1,True
        with patch('security.require_standard_user'),patch('security.dependencies',return_value=Mock()),patch('security.clam_scan',return_value=self.defs) as clam,patch('security.yara_scan') as yara,patch('security.reconstruct',side_effect=rebuild):
            r=s.native_worker('inspect',self.root,folder)
        self.assertEqual(r['verdict'],'passed');self.assertEqual(clam.call_count,2);self.assertEqual(yara.call_count,2)
    def test_worker_second_scan_detection(self):
        folder=self.root/'job';folder.mkdir();(folder/'input.quarantine').write_bytes(SAMPLE)
        def rebuild(src,dest):dest.write_bytes(DERIVATIVE);return 'text',1,True
        with patch('security.require_standard_user'),patch('security.dependencies',return_value=Mock()),patch('security.clam_scan',side_effect=[self.defs,s.Blocked('mock threat','malware')]),patch('security.yara_scan'),patch('security.reconstruct',side_effect=rebuild):
            r=s.native_worker('inspect',self.root,folder)
        self.assertEqual(r['verdict'],'malware')

class RealPDFTests(unittest.TestCase):
    def setUp(self):
        try:import pymupdf;self.f=pymupdf;s.tessdata()
        except (ImportError,s.Blocked) as e:self.skipTest(str(e))
        self.td=tempfile.TemporaryDirectory();self.addCleanup(self.td.cleanup);self.root=Path(self.td.name)
    def test_real_ocr_reconstruction(self):
        src=self.root/'input.quarantine';out=self.root/'rebuilt.pending'
        with self.f.open() as d:
            p=d.new_page(width=400,height=200);p.insert_text((20,45),'Social hostility and group dynamics',fontsize=15);d.save(str(src))
        text,pages,searchable=s.reconstruct(src,out)
        self.assertTrue(searchable);self.assertIn('social hostility',text.lower());self.assertEqual(pages,1)
        with self.f.open(str(out),filetype='pdf') as d:
            self.assertTrue(d[0].get_images());self.assertFalse(d[0].get_links());self.assertIn('Social hostility',d[0].get_text())
    def test_real_image_only_becomes_searchable(self):
        src=self.root/'input.quarantine';out=self.root/'rebuilt.pending'
        with self.f.open() as base,self.f.open() as d:
            p=base.new_page(width=400,height=200);p.insert_text((20,45),'Collective resentment in society',fontsize=15)
            pix=p.get_pixmap(dpi=180);d.new_page(width=400,height=200).insert_image(p.rect,pixmap=pix);d.save(str(src))
        with self.f.open(str(src),filetype='pdf') as d:self.assertFalse(d[0].get_text().strip())
        text,pages,searchable=s.reconstruct(src,out);self.assertTrue(searchable);self.assertIn('collective resentment',text.lower())
    def test_real_attachment_rejected(self):
        src=self.root/'input.quarantine';out=self.root/'rebuilt.pending'
        with self.f.open() as d:
            d.new_page();d.embfile_add('note.txt',b'harmless attachment');d.save(str(src))
        with self.assertRaises(s.Blocked):s.reconstruct(src,out)
        self.assertFalse(out.exists())
    def test_real_encrypted_rejected(self):
        src=self.root/'input.quarantine';out=self.root/'rebuilt.pending'
        with self.f.open() as d:
            d.new_page();d.save(str(src),encryption=self.f.PDF_ENCRYPT_AES_256,owner_pw='test-owner',user_pw='test-user')
        with self.assertRaises(s.Blocked):s.reconstruct(src,out)
        self.assertFalse(out.exists())

if __name__=='__main__':unittest.main()
