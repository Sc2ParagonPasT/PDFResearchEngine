/* Conservative PDF policy rules, authored for this application.
   These are heuristic flags, not a maintained malware-signature feed.
   A match quarantines; never labels a file as definitively infected. */
rule PDF_Active_Action : suspicious_pdf {
    meta:
        description = "Raw PDF names associated with executable or automatic actions"
    strings:
        $header = "%PDF-" ascii
        $active = /\/(JavaScript|JS|Launch|OpenAction|AA|SubmitForm|ImportData|GoToR|GoToE)([^a-zA-Z0-9_]|$)/ ascii
    condition:
        $header at 0 and $active
}
rule PDF_Attachment_Or_Multimedia : suspicious_pdf {
    strings:
        $header = "%PDF-" ascii
        $feature = /\/(EmbeddedFile|EmbeddedFiles|RichMedia|XFA|Movie|Sound|Rendition|3D)([^a-zA-Z0-9_]|$)/ ascii
    condition:
        $header at 0 and $feature
}
