"""Dark-mode desktop interface; run with Python 3.10+."""
import json, os, queue, threading, sys, tkinter as tk
from pathlib import Path
from tkinter import ttk, messagebox, filedialog
from engine import *
from security import Pipeline, ScreenedLibrary, Blocked, worker_entry, single_instance

BG='#11151b'; PANEL='#1b222c'; FG='#e5eaf2'; MUTED='#a3b0c2'; ACCENT='#315b89'; BORDER='#394653'
ROOT=Path(os.environ.get('LOCALAPPDATA',str(Path.home()/'.local/share')))/'PDFResearchV02'
class App:
    def __init__(self,win):
        self.win=win;win.title('PDF Research | v0.2');win.geometry('1180x820');win.minsize(1000,700);win.configure(bg=BG)
        self.root=ROOT;self.root.mkdir(parents=True,exist_ok=True);self.lib=ScreenedLibrary(self.root);self.config=self.root/'settings.json'
        self.hosts=DEFAULT_HOSTS[:];self.seeds=[];self.threat_action='delete';self.auto_rescan=True
        if self.config.exists():
            try:
                d=json.loads(self.config.read_text());self.hosts=sorted(exact_hosts(d['hosts']));self.seeds=d.get('seeds',[]);self.threat_action=d.get('threat_action','delete');self.threat_action=self.threat_action if self.threat_action in ('delete','quarantine') else 'delete';self.auto_rescan=bool(d.get('auto_rescan',True))
            except Exception:pass
        self.events=queue.Queue();self.stop=threading.Event();self.busy=False;self.results={};self.docids={};self.terms=[]
        self.style();self.layout();self.refresh_library();self.win.after(100,self.poll)
        win.protocol('WM_DELETE_WINDOW',self.close)
        self.win.after(200,self.check_security)
    def style(self):
        self.win.option_add('*Font','{Segoe UI} 10');self.win.option_add('*TCombobox*Listbox.background',PANEL);self.win.option_add('*TCombobox*Listbox.foreground',FG)
        s=ttk.Style(self.win);s.theme_use('clam');s.configure('.',background=BG,foreground=FG,fieldbackground=PANEL,bordercolor=BORDER,lightcolor=BORDER,darkcolor=BORDER,insertcolor=FG)
        s.configure('TButton',background=PANEL,foreground=FG,padding=(10,7));s.map('TButton',background=[('active','#344354'),('disabled','#1b222c')],foreground=[('disabled','#697787')]);s.configure('Accent.TButton',background=ACCENT);s.map('Accent.TButton',background=[('active','#4378aa')]);s.configure('TNotebook.Tab',padding=(15,9),background=PANEL);s.map('TNotebook.Tab',background=[('selected',ACCENT)]);s.configure('Treeview',background=PANEL,fieldbackground=PANEL,foreground=FG,rowheight=29);s.configure('Treeview.Heading',background='#263343',foreground=FG);s.map('Treeview',background=[('selected',ACCENT)]);s.configure('Vertical.TScrollbar',background='#394653',troughcolor=BG,arrowcolor=FG,bordercolor=BORDER);s.configure('Horizontal.TScrollbar',background='#394653',troughcolor=BG,arrowcolor=FG,bordercolor=BORDER);s.configure('Muted.TLabel',foreground=MUTED);s.configure('Title.TLabel',font=('Segoe UI',22,'bold'));s.configure('TCombobox',fieldbackground=PANEL,foreground=FG);s.map('TCombobox',fieldbackground=[('readonly',PANEL)],selectbackground=[('readonly',PANEL)],selectforeground=[('readonly',FG)])
    def label(self,parent,text,muted=False):return ttk.Label(parent,text=text,style='Muted.TLabel' if muted else 'TLabel',wraplength=1050)
    def text(self,parent,height=6):return tk.Text(parent,height=height,bg=PANEL,fg=FG,insertbackground=FG,selectbackground=ACCENT,relief='flat',padx=10,pady=8,wrap='word',font=('Segoe UI',10))
    def layout(self):
        shell=ttk.Frame(self.win,padding=18);shell.pack(fill='both',expand=True)
        ttk.Label(shell,text='PDF RESEARCH  /  v0.2',style='Title.TLabel',font=('Segoe UI',21,'bold')).pack(anchor='w');self.label(shell,'LOCAL DISCOVERY  /  APPROVED SOURCES  /  NO PAID SERVICES',True).pack(anchor='w',pady=(1,5));self.health=tk.StringVar(value='Security not checked');ttk.Label(shell,textvariable=self.health,wraplength=1050,style='Muted.TLabel').pack(anchor='w',pady=(0,10))
        nb=ttk.Notebook(shell);nb.pack(fill='both',expand=True);self.discovery=ttk.Frame(nb,padding=12);self.library=ttk.Frame(nb,padding=12);self.sources=ttk.Frame(nb,padding=12);nb.add(self.discovery,text='Discovery');nb.add(self.library,text='Local library');nb.add(self.sources,text='Sources & security')
        d=self.discovery;top=ttk.Frame(d);top.pack(fill='x');self.q=tk.StringVar(value='');ttk.Entry(top,textvariable=self.q).pack(side='left',fill='x',expand=True,ipady=6);self.depth=tk.StringVar(value='Comprehensive');ttk.Combobox(top,textvariable=self.depth,values=['Focused','Comprehensive','Extensive'],state='readonly',width=15).pack(side='left',padx=8);ttk.Button(top,text='Expand terms',command=self.generate).pack(side='left');
        self.label(d,'Enter a research topic, e.g. Hatred in society, sociology papers. Edit generated terms below.',True).pack(anchor='w',pady=(9,4));self.termtext=self.text(d,5);self.termtext.pack(fill='x');self.generate()
        opts=ttk.Frame(d);opts.pack(fill='x',pady=8);self.providers={p:tk.BooleanVar(value=p in ('ERIC','Europe PMC','Crossref')) for p in PROVIDERS}
        for p,v in self.providers.items():ttk.Checkbutton(opts,text=p,variable=v).pack(side='left',padx=(0,12))
        self.crawlvar=tk.BooleanVar(value=False);ttk.Checkbutton(opts,text='Crawl approved seed pages',variable=self.crawlvar).pack(side='left')
        actions=ttk.Frame(d);actions.pack(fill='x',pady=(0,8));self.searchbtn=ttk.Button(actions,text='Search approved sources',style='Accent.TButton',command=self.search);self.searchbtn.pack(side='left');ttk.Button(actions,text='Stop',command=self.stop.set).pack(side='left',padx=6);ttk.Button(actions,text='Check PDF headers',command=lambda:self.selected_action('verify')).pack(side='left');self.inspectbtn=ttk.Button(actions,text='Inspect & index selected',style='Accent.TButton',command=lambda:self.selected_action('download'));self.inspectbtn.pack(side='left',padx=6);ttk.Button(actions,text='Copy source URL',command=self.copy_url).pack(side='left')
        self.tree=self.table(d,[('title','Document',410),('source','Source',100),('year','Year',55),('status','Verification status',190),('query','Discovery term',210)]);self.tree.bind('<<TreeviewSelect>>',self.selection)
        self.url=tk.StringVar(value='Select a result to inspect its source URL.');ttk.Entry(d,textvariable=self.url,state='readonly').pack(fill='x',pady=(6,4))
        self.logs=self.text(d,3);self.logs.pack(fill='x');self.logs.insert('1.0','Ready. Discovery results are unverified. Inspect & index retrieves privately, scans and reconstructs; no original is opened.');self.logs.configure(state='disabled')
        l=self.library;lt=ttk.Frame(l);lt.pack(fill='x',pady=(0,8));self.lq=tk.StringVar();ttk.Entry(lt,textvariable=self.lq).pack(side='left',fill='x',expand=True,ipady=6);ttk.Button(lt,text='Search titles & text',command=self.refresh_library).pack(side='left',padx=6);ttk.Button(lt,text='Rescan & export PDF',style='Accent.TButton',command=self.export_selected).pack(side='left');ttk.Button(lt,text='Recheck library',command=self.recheck_library).pack(side='left',padx=6);self.lq.trace_add('write',lambda *_:self.refresh_library());self.lt=self.table(l,[('title','Document',420),('source','Source',110),('year','Year',65),('status','Inspection status',220),('pages','Pages',55)]);self.lt.bind('<<TreeviewSelect>>',self.preview);self.label(l,'Searchable OCR text from the reconstructed copy (not the original).',True).pack(anchor='w',pady=(9,3));self.previewtext=self.text(l,10);self.previewtext.pack(fill='both',expand=True);self.previewtext.configure(state='disabled')
        s=self.sources;self.label(s,'Approved HTTPS hostnames — exact matches only. Add a hostname only after independently reviewing it.').pack(anchor='w');self.hosttext=self.text(s,8);self.hosttext.pack(fill='x',pady=(5,12));self.hosttext.insert('1.0','\n'.join(self.hosts));self.label(s,'Optional crawl start URLs — one approved publication or archive page per line.').pack(anchor='w');self.seedtext=self.text(s,4);self.seedtext.pack(fill='x',pady=(5,12));self.seedtext.insert('1.0','\n'.join(self.seeds));r=ttk.Frame(s);r.pack(fill='x');self.label(r,'Confirmed malware:').pack(side='left');self.policy=tk.StringVar(value=self.threat_action);ttk.Combobox(r,textvariable=self.policy,values=['delete','quarantine'],width=12,state='readonly').pack(side='left',padx=8);ttk.Button(r,text='Save sources & policy',style='Accent.TButton',command=self.save_sources).pack(side='left');ttk.Button(r,text='Check security',command=self.check_security).pack(side='left',padx=6);ttk.Button(r,text='Update definitions',command=self.update_security).pack(side='left')
        self.rescanvar=tk.BooleanVar(value=self.auto_rescan);ttk.Checkbutton(s,text='Recheck cached PDFs after a successful manual definition update',variable=self.rescanvar).pack(anchor='w',pady=(10,4));ttk.Label(s,textvariable=self.health,wraplength=1000,style='Muted.TLabel').pack(anchor='w',pady=(4,4))
        self.label(s,'Mandatory ClamAV + YARA + structural checks and English OCR. No raw PDF export. Failed checks block release; suspicious files are quarantined. Definitions older than seven days block processing until updated. Export rescans the exact reconstructed bytes.').pack(anchor='w',pady=(6,4));self.label(s,'Security boundary: the local worker runs as your user, not inside an OS sandbox. Use a non-admin account. This is not an independently audited antivirus or a guarantee of safety.').pack(anchor='w',pady=(6,4));self.label(s,'Data directory: '+str(self.root),True).pack(anchor='w');self.label(s,'Default hosts are candidates for approval, not a safety certification. FreshClam uses its own separate vendor update channel.',True).pack(anchor='w',pady=5)
        self.status=tk.StringVar(value='Ready');ttk.Label(shell,textvariable=self.status,style='Muted.TLabel').pack(anchor='w',pady=(8,0))
    def table(self,parent,cols):
        frame=ttk.Frame(parent);frame.pack(fill='both',expand=True);tree=ttk.Treeview(frame,columns=[c[0] for c in cols],show='headings',selectmode='extended',height=8);ys=ttk.Scrollbar(frame,orient='vertical',command=tree.yview);xs=ttk.Scrollbar(frame,orient='horizontal',command=tree.xview);tree.configure(yscrollcommand=ys.set,xscrollcommand=xs.set);tree.grid(row=0,column=0,sticky='nsew');ys.grid(row=0,column=1,sticky='ns');xs.grid(row=1,column=0,sticky='ew');frame.rowconfigure(0,weight=1);frame.columnconfigure(0,weight=1)
        for key,label,width in cols:tree.heading(key,text=label);tree.column(key,width=width,minwidth=45,stretch=key=='title')
        return tree
    def generate(self):
        self.terms=expand(self.q.get(),self.depth.get());self.termtext.delete('1.0','end');self.termtext.insert('1.0','\n'.join(self.terms));self.generated_query=self.q.get();self.generated_depth=self.depth.get()
    def save_sources(self):
        if self.busy:messagebox.showinfo('Busy','Stop the current operation before changing sources.');return
        try:
            hosts=exact_hosts(self.hosttext.get('1.0','end').splitlines());seeds=[checked_url(x.strip(),hosts) for x in self.seedtext.get('1.0','end').splitlines() if x.strip()];self.hosts=sorted(hosts);self.seeds=seeds[:12];self.threat_action=self.policy.get();self.auto_rescan=self.rescanvar.get();self.config.write_text(json.dumps({'hosts':self.hosts,'seeds':self.seeds,'threat_action':self.threat_action,'auto_rescan':self.auto_rescan},indent=2));self.status.set('Approved sources saved.')
        except Exception as e:messagebox.showerror('Invalid settings',str(e))
    def start(self,fn):
        if self.busy:messagebox.showinfo('Busy','An operation is already running.');return False
        self.busy=True;self.stop.clear();self.searchbtn.configure(state='disabled')
        def work():
            try:fn()
            except Exception as e:self.events.put(('log',str(e)))
            finally:self.events.put(('idle',None))
        threading.Thread(target=work,daemon=True).start();return True
    def search(self):
        if self.busy:return
        if self.generated_query!=self.q.get() or self.generated_depth!=self.depth.get():self.generate()
        terms=list(dict.fromkeys(x.strip()[:240] for x in self.termtext.get('1.0','end').splitlines() if x.strip()))[:24];providers=[p for p,v in self.providers.items() if v.get()];seeds=self.seeds if self.crawlvar.get() else []
        if not terms or not (providers or seeds):messagebox.showinfo('Search','Enter search terms and enable at least one source.');return
        self.tree.delete(*self.tree.get_children());self.results.clear();net=Network(self.hosts);self.status.set('Searching approved sources…');self.start(lambda:run_search(net,providers,terms,seeds,self.stop,lambda k,v:self.events.put((k,v))))
    def selection(self,_=None):
        ids=self.tree.selection();self.url.set(self.results[ids[0]].url if ids else '')
    def copy_url(self):
        ids=self.tree.selection()
        if ids:self.win.clipboard_clear();self.win.clipboard_append(self.results[ids[0]].url)
    def pipeline(self):return Pipeline(self.root,self.threat_action)
    def check_security(self):
        if self.busy:return
        def work():
            try:r=self.pipeline().status();self.events.put(('health',r))
            except Exception as e:self.events.put(('health',{'verdict':'unavailable','reason':str(e)}))
        self.start(work)
    def recheck_all(self,pipe):
        docs=self.lib.active_digests()
        for i,digest in enumerate(docs,1):
            if self.stop.is_set():break
            self.events.put(('progress',f'Rechecking cached PDF {i}/{len(docs)}'))
            try:pipe.recheck(digest)
            except Blocked as e:
                if e.verdict in ('malware','suspicious'):self.lib.blocked(digest,str(e))
                self.events.put(('log','Library rescan: '+str(e)))
                if e.verdict=='unavailable':break
            except Exception as e:self.events.put(('log','Library rescan failed: '+str(e)));break
        self.events.put(('library',None))
    def recheck_library(self):
        if self.busy:return
        pipe=self.pipeline()
        def work():
            try:self.events.put(('health',pipe.ensure_ready()));self.recheck_all(pipe)
            except Exception as e:self.events.put(('log','Library recheck blocked: '+str(e)))
        self.start(work)
    def update_security(self):
        if self.busy:return
        auto=self.rescanvar.get();pipe=self.pipeline()
        def work():
            self.events.put(('progress','Updating ClamAV definitions from the vendor…'))
            try:
                r=pipe.update();self.events.put(('health',r))
                if r.get('verdict')=='ready' and auto:self.recheck_all(pipe)
            except Exception as e:self.events.put(('health',{'verdict':'unavailable','reason':str(e)}))
        self.start(work)
    def selected_action(self,action):
        if self.busy:return
        ids=self.tree.selection()
        if not ids:return
        if len(ids)>30:messagebox.showinfo('Batch limit','Select at most 30 documents at a time.');return
        if action=='download' and not messagebox.askyesno('Secure inspection',f'Inspect {len(ids)} selected candidate(s)? This retrieves files into temporary storage, scans both original and reconstructed copies, and indexes only passing searchable derivatives. The native worker is not an OS sandbox.'):return
        selected=[(i,self.results[i]) for i in ids];net=Network(self.hosts);pipe=self.pipeline()
        def work():
            if action=='download':
                self.events.put(('progress','Checking mandatory security tools and definitions…'))
                try:self.events.put(('health',pipe.ensure_ready()))
                except Exception as e:self.events.put(('health',{'verdict':'unavailable','reason':str(e)}));return
            for i,r in selected:
                if self.stop.is_set():break
                try:
                    if action=='verify':
                        net.probe(r.url);r.status='PDF header confirmed / unscanned'
                    else:
                        r.status='Retrieving / inspecting';self.events.put(('update',(i,dataclasses.replace(r))))
                        evidence=pipe.process(net,r)
                        if evidence['verdict']=='passed':
                            self.lib.save(r,evidence);r.digest=evidence['digest'];r.status='Screened / OCR indexed'
                        else:
                            r.status=evidence['verdict'].capitalize()+' / '+evidence.get('disposition','blocked');self.events.put(('log',r.title[:75]+': '+evidence.get('reason','Blocked')[:240]))
                except Exception as e:r.status='Rejected / unavailable';self.events.put(('log',r.title[:75]+': '+str(e)[:150]))
                self.events.put(('update',(i,r)));self.events.put(('progress',r.status))
            self.events.put(('library',None))
        self.start(work)
    def export_selected(self):
        if self.busy:return
        ids=self.lt.selection()
        if not ids:return
        docs=list(dict.fromkeys(self.docids[i] for i in ids))[:30]
        folder=filedialog.askdirectory(title='Export screened OCR PDFs to folder',mustexist=True)
        if not folder:return
        pipe=self.pipeline()
        def work():
            for digest in docs:
                if self.stop.is_set():break
                try:
                    self.events.put(('progress','Rescanning reconstructed PDF before export…'))
                    target=pipe.export(digest,folder);self.events.put(('log','Exported '+str(target)))
                except Blocked as e:
                    if e.verdict in ('malware','suspicious'):self.lib.blocked(digest,str(e))
                    self.events.put(('log','Export blocked: '+str(e)))
                except Exception as e:self.events.put(('log','Export failed: '+str(e)))
            self.events.put(('library',None))
        self.start(work)
    def refresh_library(self):
        if not hasattr(self,'lt'):return
        self.lt.delete(*self.lt.get_children());self.docids.clear()
        for digest,title,source,year,status,url,pages in self.lib.search(self.lq.get()):
            i=self.lt.insert('', 'end',values=(title,source,year,status,pages));self.docids[i]=digest
    def preview(self,_=None):
        ids=self.lt.selection();body=self.lib.text(self.docids[ids[0]]) if ids else '';self.previewtext.configure(state='normal');self.previewtext.delete('1.0','end');self.previewtext.insert('1.0',body or 'No available indexed text. Original files are never exported.');self.previewtext.configure(state='disabled')
    def row(self,r):return (r.title,r.source,r.year,r.status,r.query)
    def poll(self):
        try:
            while True:
                k,v=self.events.get_nowait()
                if k=='result':i=self.tree.insert('','end',values=self.row(v));self.results[i]=v
                elif k=='update':i,r=v;self.results[i]=r;self.tree.item(i,values=self.row(r))
                elif k in ('progress','done'):self.status.set(v)
                elif k=='library':self.refresh_library()
                elif k=='health':
                    msg='Security prerequisites available; document scans still required.' if v.get('verdict')=='ready' else 'Security unavailable: '+v.get('reason','Unknown failure')
                    self.health.set(msg);self.status.set(msg)
                elif k=='idle':self.busy=False;self.searchbtn.configure(state='normal')
                elif k=='log':self.logs.configure(state='normal');self.logs.insert('end','\n'+str(v)[:500]);self.logs.see('end');self.logs.configure(state='disabled');self.status.set(str(v)[:160])
        except queue.Empty:pass
        self.win.after(100,self.poll)
    def close(self):
        if self.busy:
            self.stop.set();messagebox.showinfo('Operation running','Cancellation requested. Wait for the current bounded operation to finish before closing.');return
        self.stop.set();self.win.destroy()
if __name__=='__main__':
    if len(sys.argv)==5 and sys.argv[1]=='--security-worker':worker_entry(sys.argv[2:])
    elif len(sys.argv)==3 and sys.argv[1] in ('--diagnostics','--live-self-test'):
        from diagnostics import diagnostics
        sys.exit(0 if diagnostics(sys.argv[2],sys.argv[1]=='--live-self-test') else 1)
    else:
        root=tk.Tk()
        try:
            with single_instance(ROOT):App(root).win.mainloop()
        except Blocked as e:messagebox.showerror('PDF Research',str(e),parent=root);root.destroy()
