"""Free, allowlist-only PDF discovery. No PDF parser runs in the host process."""
import concurrent.futures as cf
from contextlib import contextmanager
import dataclasses
import hashlib
import html
import http.client
import ipaddress
import json
import os
import re
import socket
import ssl
import sqlite3
import subprocess
import threading
import time
import uuid
import xml.etree.ElementTree as ET
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urlsplit, urljoin, urlencode, urlunsplit
from urllib.robotparser import RobotFileParser

DEFAULT_HOSTS = ['api.crossref.org','www.ebi.ac.uk','api.ies.ed.gov','files.eric.ed.gov',
                 'export.arxiv.org','arxiv.org','pmc.ncbi.nlm.nih.gov','europepmc.org',
                 'www.govinfo.gov','www.cia.gov','www.archives.gov','www.rand.org',
                 'www.loc.gov','www.nasa.gov','ntrs.nasa.gov']
PROVIDERS = ('ERIC','Europe PMC','Crossref','arXiv')
MAX_PDF = 50*1024*1024
HEADER = re.compile(rb'%PDF-[12]\.\d(?:\r|\n)')
TERM_GROUPS = {
 'hatred|hate|hostility|animosity': ['sociology of hatred','social hostility','collective resentment','intergroup prejudice','social antagonism','outgroup hostility','dehumanization','scapegoating','social exclusion','affective polarization','collective aggression','social identity theory','moral exclusion','intergroup threat','sociology of emotions','social dominance theory'],
 'propaganda|persuasion|psychological warfare|information warfare': ['mass persuasion','psychological operations','public opinion formation','information operations','strategic communication','political communication','media framing','attitude change','social influence','behavioral influence'],
 'poverty|inequality|deprivation': ['relative deprivation','social stratification','economic inequality','social mobility','wealth concentration','material hardship','social exclusion','structural inequality'],
 'trust|distrust': ['institutional trust','social capital','political legitimacy','interpersonal trust','social cohesion','public confidence','institutional legitimacy'],
 'power|authority|elite': ['political power','elite theory','institutional power','social hierarchy','authority and legitimacy','power relations','social dominance','governance'],
 'crime|criminality|violence': ['collective violence','social disorganization','criminology','social control','violent behavior','structural violence','deviance','victimization'],
 'society|sociology|social': ['social structure','collective behavior','social psychology','group dynamics','cultural sociology','social institutions','social norms'],
 'education|school|learning': ['educational attainment','pedagogy','educational inequality','learning outcomes','school climate','curriculum studies','education policy'],
 'health|medicine|disease': ['public health','epidemiology','health outcomes','clinical research','social determinants of health','health policy'],
 'economy|economics|monetary': ['economic policy','macroeconomics','financial institutions','monetary policy','political economy','economic development'],
 'technology|automation|artificial intelligence': ['technological change','digital transformation','automation and society','algorithmic governance','human computer interaction','technology adoption','sociotechnical systems'],
 'religion|religious|faith': ['sociology of religion','religious institutions','secularization','religious identity','ritual and community','religious socialization','belief systems'],
 'climate|environment|ecology': ['environmental policy','environmental sociology','climate adaptation','ecological systems','environmental governance','environmental justice','sustainability research'],
 'migration|immigration|diaspora': ['transnational migration','diaspora studies','integration and assimilation','migration policy','social integration','migrant communities','forced displacement'],
 'memory|history|historical': ['collective memory','historical sociology','historical archives','oral history','historiography','cultural memory','historical institutionalism'],
 'media|journalism|news': ['media effects','agenda setting','media sociology','framing theory','news production','media ownership','communication research'],
 'family|parenting|childhood': ['family sociology','socialization','intergenerational relations','family structures','child development','household dynamics'],
 'labor|employment|workforce': ['labor relations','labor economics','workplace sociology','occupational mobility','industrial relations','employment policy'],
 'culture|cultural|identity': ['cultural sociology','identity formation','cultural norms','cultural transmission','social identity','symbolic interactionism'],
}

def expand(query, depth='Comprehensive'):
    query = ' '.join(query.split())[:240]
    if not query: return []
    base = re.sub(r'\b(?:papers?|articles?|pdfs?|studies|research)\b', '', query, flags=re.I)
    base = re.sub(r'\s+,', ',', ' '.join(base.split())).strip(' ,') or query
    subject = re.split(r'[,;]', base, maxsplit=1)[0].strip()
    discipline = re.search(r'\b(sociology|psychology|economics|history|anthropology|criminology|education|medicine|political science)\b',base,re.I)
    context = discipline.group(0).lower() if discipline else ''
    found = [query,base,subject]
    for pattern, terms in TERM_GROUPS.items():
        if re.search(r'\b(?:'+pattern+r')\b',base,re.I):
            found += [t+(' '+context if context and context not in t else '') for t in terms]
    # Optional local WordNet. Never installs or downloads models at runtime.
    try:
        from nltk.corpus import wordnet as wn
        words = re.findall(r'[A-Za-z]{4,}',subject)[:4]
        for word in words:
            for syn in wn.synsets(word)[:2]:
                for lemma in syn.lemmas()[:3]:
                    s=lemma.name().replace('_',' ')
                    if s.lower()!=word.lower():
                        found.append(re.sub(r'\b'+re.escape(word)+r'\b',s,subject,flags=re.I)+(' '+context if context else ''))
    except (ImportError, LookupError): pass
    found += [subject+' literature review',subject+' empirical study',subject+' theoretical framework',subject+' historical research',subject+' systematic review']
    out=[]; seen=set()
    for s in found:
        s=' '.join(s.split())
        if s and s.lower() not in seen: seen.add(s.lower());out.append(s)
    return out[:{'Focused':5,'Comprehensive':12,'Extensive':24}.get(depth,12)]

def exact_hosts(raw):
    out=set()
    for x in raw:
        x=x.strip().lower().rstrip('.')
        if not x: continue
        if not re.fullmatch(r'(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,62}',x):
            raise ValueError('Use exact hostnames only (no URL, wildcard, or IP): '+x)
        out.add(x)
    return out

def checked_url(url, hosts):
    if not isinstance(url,str) or len(url)>4096 or any(ord(c)<33 or ord(c)==127 for c in url) or '\\' in url:
        raise ValueError('Invalid URL')
    p=urlsplit(url)
    if p.scheme!='https' or p.username is not None or p.password is not None or p.port not in (None,443) or p.hostname not in hosts:
        raise ValueError('Blocked: URL outside approved HTTPS hosts')
    if not p.netloc.isascii() or p.netloc.lower() not in (p.hostname,p.hostname+':443'):
        raise ValueError('Blocked: ambiguous hostname')
    return urlunsplit(('https',p.hostname,p.path or '/',p.query,''))

def public_ips(host):
    results=socket.getaddrinfo(host,443,type=socket.SOCK_STREAM)
    ips=list(dict.fromkeys(x[4][0] for x in results))
    if not ips or any(not ipaddress.ip_address(x).is_global or ipaddress.ip_address(x).is_multicast for x in ips):
        raise ValueError('Blocked: nonpublic DNS address')
    return ips

class PinnedHTTPS(http.client.HTTPSConnection):
    def connect(self):
        # Resolve once, then connect to an inspected address. TLS still authenticates hostname.
        ips=public_ips(self.host)
        err=None
        for ip in ips[:3]:
            sock=None
            try:
                sock=socket.create_connection((ip,443),self.timeout)
                self.sock=self._context.wrap_socket(sock,server_hostname=self.host)
                return
            except OSError as e:
                err=e
                if sock: sock.close()
        raise err or OSError('No connection')

class Network:
    def __init__(self,hosts):
        self.hosts=exact_hosts(hosts); self.lock=threading.Lock(); self.next={}
    def open(self,url,range_header=None):
        for _ in range(5):
            url=checked_url(url,self.hosts); p=urlsplit(url)
            with self.lock:
                now=time.monotonic(); at=max(now,self.next.get(p.hostname,now));self.next[p.hostname]=at+(3.0 if p.hostname=='export.arxiv.org' else 1.0)
            time.sleep(max(0,at-now))
            c=PinnedHTTPS(p.hostname,timeout=12,context=ssl.create_default_context())
            try:
                headers={'User-Agent':'PDFResearch/0.2 (personal research; bounded requests)','Accept-Encoding':'identity','Accept':'*/*'}
                if range_header: headers['Range']=range_header
                c.request('GET',p.path+('?' + p.query if p.query else ''),headers=headers)
                r=c.getresponse()
                if r.status in (301,302,303,307,308):
                    nxt=r.getheader('Location');r.close();c.close()
                    if not nxt: raise ValueError('Redirect without destination')
                    url=urljoin(url,nxt);continue
                if r.status not in (200,206): raise ValueError('HTTP '+str(r.status))
                if r.getheader('Content-Encoding','identity').lower()!='identity': raise ValueError('Unexpected response encoding')
                return c,r,url
            except Exception:
                c.close();raise
        raise ValueError('Too many redirects')
    @staticmethod
    def read_up_to(r,limit,deadline):
        data=bytearray()
        while len(data)<limit:
            if time.monotonic()>deadline:raise ValueError('Response deadline exceeded')
            part=r.read1(min(65536,limit-len(data)))
            if not part:break
            data.extend(part)
        return bytes(data)
    def bytes(self,url,limit=2*1024*1024):
        c,r,_=self.open(url)
        try:
            data=self.read_up_to(r,limit+1,time.monotonic()+35)
            if len(data)>limit: raise ValueError('Response exceeds limit')
            return data
        finally:r.close();c.close()
    def json(self,url):return json.loads(self.bytes(url))
    def probe(self,url):
        c,r,final=self.open(url,'bytes=0-1023')
        try:
            data=self.read_up_to(r,1024,time.monotonic()+25)
            if not HEADER.match(data):raise ValueError('No valid PDF header at start of response')
            return final,r.getheader('Content-Type',''),r.getheader('Content-Range','')
        finally:r.close();c.close()
    def download(self,url,folder):
        folder.mkdir(parents=True,exist_ok=True)
        temp=folder/(uuid.uuid4().hex+'.part'); c=r=None
        try:
            c,r,final=self.open(url)
            if r.status!=200:raise ValueError('Full download required')
            length=r.getheader('Content-Length')
            if length and not 0<int(length)<=MAX_PDF:raise ValueError('File exceeds 50 MB limit or invalid length')
            deadline=time.monotonic()+180
            head=self.read_up_to(r,1024,deadline)
            if not HEADER.match(head):raise ValueError('Not a PDF by signature')
            sha=hashlib.sha256();size=0;tail=b''
            with temp.open('xb') as f:
                chunk=head
                while chunk:
                    size+=len(chunk)
                    if size>MAX_PDF or time.monotonic()>deadline:raise ValueError('Download limit exceeded')
                    sha.update(chunk);f.write(chunk);tail=(tail+chunk)[-4096:];chunk=r.read1(65536)
            if length and size!=int(length):raise ValueError('Incomplete download')
            if not re.search(rb'%%EOF\s*$',tail):raise ValueError('Missing PDF end marker; rejected')
            digest=sha.hexdigest(); dest=folder/(digest+'.quarantine')
            if dest.exists():temp.unlink()
            else:os.replace(temp,dest)
            return dest,digest,size,final
        finally:
            if r:r.close()
            if c:c.close()
            if temp.exists():temp.unlink()

@dataclasses.dataclass
class Result:
    title:str;url:str;source:str;year:str='';query:str='';status:str='Candidate (unverified)';digest:str=''

def safe_title(x):
    return ' '.join(html.unescape(re.sub(r'<[^>]+>',' ',str(x or 'Untitled'))).split())[:400]

def discover(net,provider,term):
    items=[]
    def add(title,url,year=''):
        try:url=checked_url(url,net.hosts)
        except (ValueError,TypeError):return
        items.append(Result(safe_title(title),url,provider,str(year or '')[:10],term))
    if provider=='ERIC':
        # Public bibliographic endpoint. Construct candidate PDF URLs; verify separately.
        data=net.json('https://api.ies.ed.gov/eric/?'+urlencode({'search':term,'format':'json','rows':12,'start':0}))
        for d in data.get('response',{}).get('docs',[]):
            id=d.get('id','')
            if re.fullmatch(r'E[DJ]\d+',id):add(d.get('title'),'https://files.eric.ed.gov/fulltext/'+id+'.pdf',d.get('publicationdateyear'))
    elif provider=='Europe PMC':
        data=net.json('https://www.ebi.ac.uk/europepmc/webservices/rest/search?'+urlencode({'query':term+' AND OPEN_ACCESS:Y','format':'json','pageSize':12,'resultType':'core'}))
        for d in data.get('resultList',{}).get('result',[]):
            for u in d.get('fullTextUrlList',{}).get('fullTextUrl',[]):
                if str(u.get('documentStyle','')).lower()=='pdf' and str(u.get('availabilityCode','')).upper() in ('OA','F',''):
                    add(d.get('title'),u.get('url'),d.get('pubYear'))
            # Europe PMC's open full-text PDF route; can return a blocked redirect or HTML.
            pmcid=d.get('pmcid','')
            if re.fullmatch(r'PMC\d+',pmcid):add(d.get('title'),'https://europepmc.org/articles/'+pmcid+'?pdf=render',d.get('pubYear'))
    elif provider=='Crossref':
        data=net.json('https://api.crossref.org/works?'+urlencode({'query.bibliographic':term,'filter':'has-full-text:1','rows':15,'select':'title,link,published'}))
        for d in data.get('message',{}).get('items',[]):
            year=(d.get('published',{}).get('date-parts') or [['']])[0][0]
            for u in d.get('link',[]):
                link=u.get('URL','')
                if u.get('content-type')=='application/pdf' or urlsplit(link).path.lower().endswith('.pdf'):
                    add((d.get('title') or ['Untitled'])[0],link,year)
    elif provider=='arXiv':
        phrase=' '.join(re.findall(r'[\w -]+',term))[:200]
        raw=net.bytes('https://export.arxiv.org/api/query?'+urlencode({'search_query':'all:"'+phrase+'"','start':0,'max_results':10}))
        if re.search(rb'<!\s*(DOCTYPE|ENTITY)',raw,re.I):raise ValueError('Unsafe XML')
        root=ET.fromstring(raw);ns={'a':'http://www.w3.org/2005/Atom'}
        for e in root.findall('a:entry',ns):
            for link in e.findall('a:link',ns):
                if link.get('title')=='pdf' or link.get('type')=='application/pdf':
                    u=link.get('href','');u=re.sub(r'^http://arxiv\.org/','https://arxiv.org/',u)
                    add(e.findtext('a:title',default='Untitled',namespaces=ns),u,e.findtext('a:published',default='',namespaces=ns)[:4])
    return items

class Links(HTMLParser):
    def __init__(self):super().__init__(convert_charrefs=True);self.links=[];self.current=None
    def handle_starttag(self,tag,attrs):
        if tag=='a':
            d=dict(attrs);self.current=[d.get('href',''),'']
    def handle_data(self,data):
        if self.current:self.current[1]+=data[:500]
    def handle_endtag(self,tag):
        if tag=='a' and self.current:self.links.append(self.current);self.current=None

def crawl(net,seeds,query,stop,limit=12):
    queue=list(seeds);seen=set();out=[];robots={};words=set(re.findall(r'[a-z]{4,}',query.lower()))-{'papers','research','study','articles','society'}
    while queue and len(seen)<limit and not stop.is_set():
        url=queue.pop(0)
        try:url=checked_url(url,net.hosts)
        except ValueError:continue
        if url in seen:continue
        seen.add(url)
        try:
            host=urlsplit(url).hostname
            if host not in robots:
                try:
                    rules=RobotFileParser();rules.parse(net.bytes('https://'+host+'/robots.txt',256*1024).decode('utf-8','replace').splitlines());robots[host]=rules
                except Exception:
                    robots[host]=None
            if robots[host] is None or not robots[host].can_fetch('PDFResearchPrototype',url):continue
            if urlsplit(url).path.lower().endswith('.pdf'):
                out.append(Result(urlsplit(url).path.rsplit('/',1)[-1],url,'Approved site','',''+query));continue
            parser=Links();parser.feed(net.bytes(url,1024*1024).decode('utf-8','replace'))
            for link,title in parser.links[:1000]:
                try:u=checked_url(urljoin(url,link),net.hosts)
                except (ValueError,TypeError):continue
                text=(u+' '+title).lower();match=not words or any(w in text for w in words)
                if urlsplit(u).path.lower().endswith('.pdf') or re.search(r'\bpdf\b',title,re.I):
                    if match:out.append(Result(safe_title(title or u),u,'Approved site','',query))
                elif match and u not in seen and len(queue)<limit*3:queue.append(u)
        except Exception:continue
    return out

def run_search(net,providers,terms,seeds,stop,emit):
    tasks=[(p,t) for t in terms for p in providers]; seen=set()
    def job(p,t):
        if stop.is_set():return []
        return discover(net,p,t)
    def publish(items):
        for item in items:
            if item.url not in seen:seen.add(item.url);emit('result',item)
    with cf.ThreadPoolExecutor(max_workers=5) as pool:
        futures={pool.submit(job,p,t):(p,t) for p,t in tasks}
        if seeds:futures[pool.submit(crawl,net,seeds,terms[0],stop)]=('Site crawl',terms[0])
        total=len(futures)
        for i,f in enumerate(cf.as_completed(futures),1):
            if stop.is_set():
                for f2 in futures:f2.cancel()
                break
            p,t=futures[f]
            try:publish(f.result())
            except Exception as e:emit('log',f'{p}: {str(e)[:200]}')
            emit('progress',f'{i}/{total} searches complete • {len(seen)} unique candidate URLs')
    emit('done',f'{len(seen)} candidates found'+(' (stopped)' if stop.is_set() else ''))

class Library:
    def __init__(self,root):
        self.root=Path(root);self.root.mkdir(parents=True,exist_ok=True)
        self.db=self.root/'library.sqlite3'
        with self.connect() as c:
            c.execute('CREATE TABLE IF NOT EXISTS docs (digest TEXT PRIMARY KEY,title TEXT,url TEXT,source TEXT,year TEXT,size INTEGER,status TEXT,body TEXT DEFAULT "")')
    @contextmanager
    def connect(self):
        c=sqlite3.connect(self.db,timeout=10)
        try:
            with c:yield c
        finally:c.close()
    def save(self,result,digest,size,url):
        with self.connect() as c:c.execute('INSERT OR IGNORE INTO docs(digest,title,url,source,year,size,status) VALUES(?,?,?,?,?,?,?)',(digest,result.title,url,result.source,result.year,size,'Quarantined / unscanned'))
    def update(self,digest,status,body=''):
        with self.connect() as c:c.execute('UPDATE docs SET status=?,body=? WHERE digest=?',(status,body[:1000000],digest))
    def search(self,query=''):
        # Parameterized SQL; literal substring search, not SQL wildcard interpretation.
        with self.connect() as c:return c.execute('SELECT digest,title,source,year,status,url FROM docs WHERE instr(lower(title||" "||body),lower(?))>0 OR ?="" ORDER BY rowid DESC LIMIT 1000',(query,query)).fetchall()
    def text(self,digest):
        with self.connect() as c:
            r=c.execute('SELECT body FROM docs WHERE digest=?',(digest,)).fetchone();return r[0] if r else ''

