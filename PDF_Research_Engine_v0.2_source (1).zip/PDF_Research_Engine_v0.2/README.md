# PDF Research Engine v0.2 — security-focused development prototype

**Status: source and Windows build recipe, not a compiled Windows executable.** The app and build instructions are supplied together. This environment is Linux, has no Windows compiler/runtime or ClamAV/YARA installed, and could not download dependencies. The Windows packaging workflow is written but has not been executed. Do not mistake this source package for a completed, audited antivirus or release-ready application.

The intended distribution format is one `PDFResearchEngine.exe` for Windows x64. No Python installation, separate scanner installation, subscription, API key, or account should be necessary for the eventual end user. The executable must create managed data files and download/update free virus definitions on first use. A truly disk-file-free antivirus is not practical.

## What changed since v0.1

- Dark-mode desktop application; Discovery, Local library, and Sources & security tabs.
- Free keyless research discovery: ERIC, Europe PMC, Crossref, arXiv, plus bounded approved-site crawling. Expanded built-in terminology across additional disciplines. Focused (up to 5), Comprehensive (up to 12), and Extensive (up to 24) search queries. No remote AI; optional WordNet only when present in source environment. The packaged build excludes NLTK, so it uses the embedded vocabulary and generic academic variants.
- Exact HTTPS hostname allowlist, including redirect checks, TLS certificate verification, pinned public DNS address connections, bounded responses, and 50 MB input limit. Content is checked by actual PDF header/end markers rather than by extension or MIME type alone.
- Separate, mandatory ClamAV and YARA inspection, PDF structure and active-content checks, English OCR reconstruction, second scans of reconstructed bytes, and fresh rescan before export.
- Confirmed ClamAV malware detections are deleted by default; optional quarantine. YARA policy matches, active content and other suspicious findings are quarantined. Failed/unavailable checks prevent export and indexing. Unscanned temporary files are removed on ordinary error handling. Deletion is not a forensic secure wipe.
- Searchable PDF derivatives rebuilt solely from rendered page pixels with an OCR text layer; no original PDF objects, attachments, forms, links, scripts or annotations are copied into the derivative. Original is discarded after a passing inspection. Logs retain source URL and original/derivative SHA-256 hashes. The library contains plain OCR text with page labels and an internal `.screened` copy. No raw PDF export or automatic opening.
- Free FreshClam definition updates; checks embedded daily database build timestamp, not just modification date. The seven-day age policy blocks work when definitions are stale. First inspection/export attempts to update missing/stale signatures, and manual update can recheck existing cached documents. Export always rescans with both engines and current definitions; already exported PDFs outside app storage cannot be recalled or rescanned automatically.
- Security audit log, duplicate index by original hash, per-document evidence, and blocking on integrity mismatch. The new v0.2 storage is intentionally separate; v0.1 unscanned files are not silently imported.

## A. Build the single Windows executable (developer/build machine only)

This is required once by whoever distributes the executable, not by each eventual user. Use a Windows x64 machine or VM with 64-bit Python 3.12 and the `py` launcher. Run as a regular user for live scanning, not elevated. A free Windows-based GitHub Actions workflow is also included in `.github/workflows/windows-build.yml`; hosting/build minutes are subject to the service's plan and policies, so a local Windows build is the no-service-dependency option.

1. Extract the source ZIP. Obtain an official, current ClamAV Windows x64 **portable ZIP** from https://www.clamav.net/downloads or the Cisco-Talos ClamAV releases repository. It must include `clamscan.exe`, `freshclam.exe`, and their associated native libraries in the same directory. Do not use an arbitrary rehosted executable. Verify the publisher's release/signature/checksum. Check dependency versions for security updates before building.
2. Obtain the English `eng.traineddata` file from the official `tesseract-ocr/tessdata_fast` repository at a pinned release or revision. Verify the expected SHA-256 against a trusted reference. The expected hashes are not supplied here because the external Windows files could not be fetched or verified. A locally computed hash alone does not authenticate a download.
3. Open PowerShell in the extracted project directory and run (replace all paths and hash placeholders):

```powershell
.\Build_Windows.ps1 `
    -ClamAVZip 'C:\verified\clamav-win-x64.zip' `
    -ClamAVSHA256 'REPLACE_WITH_64_HEX_DIGITS' `
    -EnglishTessdata 'C:\verified\eng.traineddata' `
    -TessdataSHA256 'REPLACE_WITH_64_HEX_DIGITS'
```

The script creates a temporary Windows build directory, verifies the two input hashes, installs pinned free Python dependencies into a build-only virtual environment, runs regression tests and a real component/OCR diagnostic, packages everything with PyInstaller `--onefile --windowed`, then runs the generated executable's own diagnostic. Only if those steps pass does it publish `dist\PDFResearchEngine.exe`, `BUILD_DIAGNOSTICS.json`, `BUILD_DEPENDENCIES.txt`, and `SHA256.txt`. These last three files are build records, not required for running the executable. The optional `-LiveTest` flag also fetches real ClamAV signature databases and runs an actual dual-engine clean-PDF reconstruction/export diagnostic. Run that test on a standard Windows account with network access; it may consume hundreds of megabytes. It does not use a paid API.

If using GitHub Actions instead of a Windows build machine, upload the project files including the hidden `.github` directory to a repository you control, then manually run the included workflow with the verified upstream asset URLs and hashes. It produces an artifact ZIP containing the executable and build records. Leave the live-test option off for elevated hosted runners; perform the live test as a standard user in a disposable Windows VM. Review GitHub's account and free-runner limits; an account is needed only for this optional build method, not to use the application. The workflow has not been run here.

Before distribution: run the generated executable on a clean Windows x64 VM without Python, ClamAV, YARA or OCR software installed. Confirm that its diagnostics and full real scans work. ClamAV's Windows distribution may depend on a Microsoft runtime; if a clean VM shows a missing runtime, address it in the build package using the vendor-supported, legally redistributable app-local runtime. That packaging question has not been verified here. Review license obligations in THIRD_PARTY_NOTICES.md. The executable will be unsigned unless a distributor separately signs it; Windows may warn or refuse to run it. Do not disable antivirus or ignore security warnings simply to run a development build.

## B. Using a successful single-file build

Launch `PDFResearchEngine.exe` under an ordinary Windows user. It checks bundled security dependencies and the freshness of definitions. If signatures have not been installed or are stale, the first inspection/export will attempt a free vendor update. You may also click Update definitions in Sources & security. Discovery-only searches can work even when the scanners are unavailable. No scanned document can enter the library when a mandatory step fails.

Type a topic (for example, Hatred in society, sociology papers). Choose a search depth and click Expand terms. Review and edit the generated terms. Select research providers and optionally enable the approved-site crawler. Click Search approved sources. Results are metadata candidates, not proof of genuine PDFs. Check PDF headers retrieves a prefix only and does not attest to file safety or text searchability.

Select up to 30 candidate rows and click Inspect & index selected. The app retrieves each selected file into its own temporary staging directory, checks its PDF signature/size/hash, runs ClamAV and YARA, performs isolated-by-process (not sandboxed) structural inspection and reconstructs a derivative using page rendering and English OCR. It scans that derivative again with both engines. Files that pass and have extractable OCR text are stored in the local library; files that fail are blocked, removed or quarantined. The discovery tab does not have a direct download-to-Downloads bypass.

In Local library, search titles and OCR text using a literal case-insensitive substring; the preview displays plain text only. Select a result and choose Rescan & export PDF. Choose a destination folder on NTFS or another hard-link-capable filesystem; the program verifies the cached hash, rescans a private copy with both engines, checks that the copy's hash is still the same, then exports the exact staged bytes. It never retrieves the source URL again at release time. Existing files are not overwritten. Export filenames use a digest prefix to avoid unsafe filenames from websites. If the filesystem cannot create an atomic hard link (e.g. some FAT/exFAT or cloud-mounted drives), export fails without a fallback. No exported PDF is automatically opened.

In Sources & security, edit the exact approved hostnames and optional seed URLs, save settings, and choose deletion or quarantine for detected malware. The default source hosts are candidate institutional/repository sources, not certified safe websites. Adding a host does not automatically give it a search API adapter. The crawler uses robots.txt and a limited matching-page traversal. Separate vendor update traffic is handled by FreshClam rather than the research crawler, so its update network channel is not governed by the document allowlist. No document is sent to that service.

## C. Source mode (development only, not the desired end-user format)

The source app can be opened using Python 3.10+ with Tkinter, by running `python app.py` or using Start_Windows.bat / Start_Linux_Mac.sh. Discovery and UI work with the standard library. Full document processing needs local ClamAV/FreshClam, yara-python, PyMuPDF, and English tessdata; on Linux ClamAV/FreshClam can be obtained through the distribution's package manager and PyMuPDF/yara-python through Python packages. Source mode finds native tools on PATH or in a local vendor tree. The frozen build never falls back to arbitrary PATH copies. No dependencies are automatically installed by the running app. Never run the prototype as administrator. For initial security testing use a disposable VM with no sensitive files and restrict inputs to benign test fixtures.

## D. Managed files

Windows: `%LOCALAPPDATA%\PDFResearchV02\` (Linux/macOS development: `~/.local/share/PDFResearchV02/`).

- `settings.json` — exact hosts, seed URLs and threat policy.
- `definitions/` — ClamAV main/daily/bytecode signature databases. Initial signatures are downloaded from the official FreshClam update service, not included in the source ZIP.
- `staging/` — transient `.part`, `.quarantine`, `.pending` files and worker result JSON; cleaned on normal completion. A system crash or forced process kill can leave residual files. Do not open them manually.
- `quarantine/` — suspicious items or detected threats if configured to retain them. A filename extension is not an operating-system security boundary. Avoid accessing quarantined files; remove them using normal antivirus-aware cleanup if you no longer need them.
- `processed/` — scanned raster/OCR derivatives with `.screened` extension, not directly opened.
- `screened.sqlite3` — local searchable index; `security.jsonl` — source, hashes, definition evidence, verdicts, reasons, and export records; `app.lock` — normal single-instance coordination.

## E. Security design and explicit limitations

The mandatory gate checks the PDF header and EOF marker, uses ClamAV and YARA on original bytes, checks PDF structure with PyMuPDF, rejects encrypted/repaired PDFs, attachments and selected active names (including escaped names), renders up to 100 pages at 150 DPI, uses English OCR, and scans the reconstructed bytes with ClamAV and YARA again. It verifies SHA-256 evidence before indexing and after an additional scan for export. The policy caps input/output at 50 MiB, pages at 100, pixel count per page at 12 million, searchable index at 400,000 characters, PDF object count at 150,000, and worker wall time at 600 seconds. A malformed, too-large, non-English or image-heavy document may be rejected or produce incomplete OCR. OCR can introduce errors; retain source URL and hashes for verification. Reconstructed PDFs are not archival originals and do not preserve digital signatures or exact visual/text fidelity.

**Critical:** this native worker runs as the same ordinary user as the desktop application, not in an OS-enforced AppContainer, virtual machine, or network-isolated sandbox. The staged data is not inaccessible to other programs running as that user. Process separation, subprocess timeouts, limits, and no automatic viewer are risk-reduction features, not a security boundary. Malformed files could exploit antivirus, PDF rendering, OCR, or network components. No scanner or sanitized derivative can guarantee safety. Do not use this build to mass-process hostile PDFs on a machine containing sensitive files. A hardened sandbox and independent security review are required before broad public release. A compromised same-user environment can modify databases, files, and program settings. An existing system antivirus remains useful, and should not be disabled.

YARA's two bundled rules are authored feature-based policy checks, not a comprehensive malware database or automatic external threat-intelligence feed. PDF-specific checks are implemented using PyMuPDF and policy rules; the upstream PDFiD and qpdf executables are not bundled in this version. Known-malware detection is delegated to ClamAV. FreshClam signature updates and scanner binaries are separate: definitions update through the vendor, but the application must be rebuilt to upgrade native engine versions or its YARA policy. The program is not a whole-computer antivirus. It cannot rescan or delete previously exported user files automatically. Local scanning does not need paid services, but bandwidth and storage are required.

## F. Tests and verification

Run `python -m unittest -v test_engine.py test_security.py`. See TEST_RESULTS.txt for the actual Linux run. Tests cover allowlisted HTTPS hosts, redirects, private DNS, header checks, deduplication, query expansion, local indexing, scan verdict routing, stale definitions, malware deletion/quarantine, output-hash mismatches, rescan enforcement, library rechecks, and lock behavior. Real PDF fixtures test raster reconstruction, OCR of digital and image-only documents, encrypted-PDF rejection, and attachment rejection. The tests simulate ClamAV and YARA responses, so their passing results establish control-flow behavior, **not real malware detection**. Neither live research endpoints nor the Windows build were tested here.

Bundled self-test modes on a completed executable (PowerShell, using a disposable standard-user Windows VM):

```powershell
Start-Process .\PDFResearchEngine.exe -ArgumentList '--diagnostics','diagnostics.json' -Wait
Start-Process .\PDFResearchEngine.exe -ArgumentList '--live-self-test','live-diagnostics.json' -Wait
```

The basic diagnostic verifies native scanner startup, compiles and matches the real YARA rules on a harmless fixture, and reconstructs a real generated PDF using bundled OCR data. The live diagnostic downloads genuine definitions and tests the clean-document pipeline and export using actual ClamAV and YARA. It does not intentionally download malicious files or include live malware. It is not an independent detection effectiveness test. Review JSON results and the security logs. A clean-machine, non-admin live test and additional safe antivirus validation using industry-standard benign test fixtures remain release gates.
